import { env } from 'cloudflare:workers';
import { currentIdentity } from '@/lib/student-auth';
export function db(): D1Database { const d=(env as any).DB; if(!d) throw new Error('دسترسی به اطلاعات کلاس‌ها موقتاً برقرار نیست.'); return d; }
export function bucket(): R2Bucket { const b=(env as any).BUCKET; if(!b)throw new Error('فضای ویدیو موقتاً در دسترس نیست.'); return b; }
export async function identity(){const u=await currentIdentity();if(!u)throw new Error('ابتدا وارد حساب خود شوید.');return u;}
export async function owner(){return (await db().prepare('SELECT value FROM settings WHERE key = ?').bind('owner').first<{value:string}>())?.value;}
export async function admin(){const u=await identity();if(u.kind!=='teacher'||await owner()!==u.userId)throw new Error('این بخش مخصوص مدرس است.');return u;}
export async function hasAccess(userId:string,courseId:string){if(await owner()===userId)return true;return !!await db().prepare('SELECT 1 FROM enrollments WHERE user_id = ? AND course_id = ? AND status = ?').bind(userId,courseId,'approved').first();}
export async function snapshot(userId?:string){const isAdmin=!!userId&&await owner()===userId;const c=await db().prepare('SELECT * FROM courses ORDER BY created DESC').all();const l=await db().prepare('SELECT id,course_id,title,size,position FROM lessons ORDER BY position,created').all();const e=isAdmin?await db().prepare('SELECT * FROM enrollments ORDER BY created DESC').all():userId?await db().prepare('SELECT * FROM enrollments WHERE user_id = ?').bind(userId).all():{results:[]};const students=isAdmin?(await db().prepare('SELECT id,username,name,active,must_change,first_name,last_name,national_id,phone,registration_source FROM students ORDER BY created DESC').all()).results:[];return {courses:c.results,lessons:l.results,enrollments:e.results,students,isAdmin};}
export function sameOrigin(req:Request){const origin=req.headers.get('origin');if(!origin||origin!==new URL(req.url).origin)throw new Error('درخواست معتبر نیست.');}
export function clean(value:unknown,max=120){if(typeof value!=='string'||!value.trim()||value.trim().length>max)throw new Error('اطلاعات واردشده معتبر نیست.');return value.trim();}
