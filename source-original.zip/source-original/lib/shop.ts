import {admin,bucket,clean,db,hasAccess,identity,owner} from '@/lib/classroom';
import type {Identity} from '@/lib/student-auth';
import type {OrderItem,PaymentDetails,ShopCourse,ShopData,ShopOrder} from './shop-types';
export class ShopError extends Error {constructor(message:string,public status=400){super(message);}}
export function fail(message:string,status=400):never{throw new ShopError(message,status);}
export async function shopStudent(){const u=await identity();if(u.kind!=='student')fail('خرید دوره از حساب شاگرد انجام می‌شود.',403);if(u.mustChange)fail('ابتدا رمز اولیهٔ حسابت را تغییر بده.',403);return u;}
export async function shopAdmin(){try{return await admin();}catch{fail('این بخش مخصوص مدیر سایت است.',403);}}
export async function paymentDetails():Promise<PaymentDetails>{
 const data=await db().prepare('SELECT key,value FROM settings WHERE key IN (?,?)').bind('payment_card','payment_owner').all<{key:string;value:string}>();
 const values=new Map(data.results.map(r=>[r.key,r.value]));
 return {cardNumber:values.get('payment_card')||'',cardOwner:values.get('payment_owner')||''};
}
export async function shopSnapshot(u:Identity|null):Promise<ShopData>{
 const isAdmin=!!u&&u.kind==='teacher'&&await owner()===u.userId;
 const courses=(await db().prepare('SELECT c.id,c.title,c.description,c.price,COUNT(l.id) AS lesson_count FROM courses c LEFT JOIN lessons l ON l.course_id = c.id GROUP BY c.id ORDER BY c.created DESC').all<ShopCourse>()).results;
 const payment=await paymentDetails();
 if(!u)return {courses,payment,isAdmin:false,cart:[],owned:[],pending:[],orders:[]};
 const scope=isAdmin?'':'WHERE user_id = ?';
 const selection=`SELECT id FROM orders ${scope} ORDER BY CASE status WHEN 'pending' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,created DESC LIMIT 200`;
 const q=db().prepare(`SELECT id,user_id,buyer_name,buyer_username,total,status,payment_card,payment_owner,receipt_text,receipt_key IS NOT NULL AS hasReceipt,review_note,created,submitted,reviewed FROM orders WHERE id IN (${selection}) ORDER BY CASE status WHEN 'pending' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,created DESC`);
 const iq=db().prepare(`SELECT order_id,course_id,title,price FROM order_items WHERE order_id IN (${selection})`);
 const [raw,items,cart,owned,pending]=await Promise.all([
  (isAdmin?q:q.bind(u.userId)).all<Omit<ShopOrder,'items'>>(),
  (isAdmin?iq:iq.bind(u.userId)).all<OrderItem&{order_id:string}>(),
  db().prepare('SELECT course_id FROM cart_items WHERE user_id = ? ORDER BY created').bind(u.userId).all<{course_id:string}>(),
  db().prepare("SELECT course_id FROM enrollments WHERE user_id = ? AND status = 'approved'").bind(u.userId).all<{course_id:string}>(),
  db().prepare("SELECT DISTINCT i.course_id FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.user_id = ? AND o.status = 'pending'").bind(u.userId).all<{course_id:string}>()
 ]);
 const orders=raw.results.map(o=>({...o,hasReceipt:!!o.hasReceipt,items:items.results.filter(i=>i.order_id===o.id).map(({course_id,title,price})=>({course_id,title,price}))}));
 return {courses,payment,isAdmin,orders,cart:cart.results.map(r=>r.course_id),owned:owned.results.map(r=>r.course_id),pending:pending.results.map(r=>r.course_id)};
}
export function digits(value:unknown){if(typeof value!=='string')return '';return value.replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));}
function price(value:unknown){if(!Number.isSafeInteger(value)||Number(value)<1||Number(value)>1_000_000_000)fail('قیمت باید عدد صحیح، از ۱ تا ۱ میلیارد تومان باشد.');return Number(value);}
async function draft(userId:string){return db().prepare("SELECT id FROM orders WHERE user_id = ? AND status = 'draft'").bind(userId).first<{id:string}>();}
export async function mutateShop(b:Record<string,unknown>){
 if(b.action==='setPrice'){
  await shopAdmin();const id=clean(b.courseId);const value=b.price===null?null:price(b.price);
  const result=await db().prepare('UPDATE courses SET price = ? WHERE id = ?').bind(value,id).run();if(!result.meta.changes)fail('دوره پیدا نشد.',404);return {ok:true};
 }
 if(b.action==='setPayment'){
  await shopAdmin();const card=digits(b.cardNumber).replace(/[\s-]/g,'');const holder=clean(b.cardOwner);
  if(!/^\d{16}$/.test(card)||/^0+$/.test(card))fail('شماره کارت باید ۱۶ رقم باشد.');
  await db().batch([db().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').bind('payment_card',card),db().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').bind('payment_owner',holder)]);
  return {ok:true};
 }
 if(b.action==='reviewOrder'){
  const reviewer=await shopAdmin();const id=clean(b.orderId);if(b.decision!=='approved'&&b.decision!=='rejected')fail('نتیجهٔ بررسی معتبر نیست.');
  const note=typeof b.note==='string'?b.note.trim():'';if(note.length>1000)fail('توضیح بررسی حداکثر ۱۰۰۰ کاراکتر باشد.');
  const o=await db().prepare('SELECT status FROM orders WHERE id = ?').bind(id).first<{status:string}>();if(!o)fail('سفارش پیدا نشد.',404);
  if(o.status===b.decision)return {ok:true,already:true};if(o.status!=='pending')fail('این سفارش در انتظار بررسی نیست.',409);
  const reviewToken=crypto.randomUUID();
  const queries=[db().prepare("UPDATE orders SET status = ?,review_note = ?,reviewer = ?,review_token = ?,reviewed = ? WHERE id = ? AND status = 'pending'").bind(b.decision,note,reviewer.userId,reviewToken,Date.now(),id)];
  if(b.decision==='approved')queries.push(db().prepare("INSERT INTO enrollments (user_id,course_id,name,email,status,created) SELECT o.user_id,i.course_id,o.buyer_name,o.buyer_username,'approved',? FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.id = ? AND o.status = 'approved' AND o.review_token = ? ON CONFLICT(user_id,course_id) DO UPDATE SET status = excluded.status").bind(Date.now(),id,reviewToken));
  const result=await db().batch(queries);if(!result[0].meta.changes)fail('این سفارش هم‌زمان بررسی شد؛ صفحه را به‌روز کن.',409);
  return {ok:true};
 }
 const u=await shopStudent();
 if(b.action==='addCart'||b.action==='removeCart'){
  if(await draft(u.userId))fail('برای تغییر سبد، ابتدا به سبد خرید برو و «ویرایش سبد» را بزن.',409);
  const id=clean(b.courseId);
  if(b.action==='removeCart'){await db().prepare('DELETE FROM cart_items WHERE user_id = ? AND course_id = ?').bind(u.userId,id).run();return {ok:true};}
  const c=await db().prepare('SELECT price FROM courses WHERE id = ?').bind(id).first<{price:number|null}>();if(!c)fail('دوره پیدا نشد.',404);if(c.price===null)fail('قیمت این دوره هنوز تعیین نشده است.');
  if(await hasAccess(u.userId,id))fail('این دوره از قبل برای تو فعال است.');
  if(await db().prepare("SELECT 1 FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.user_id = ? AND i.course_id = ? AND o.status = 'pending'").bind(u.userId,id).first())fail('خرید این دوره قبلاً برای بررسی مالی ارسال شده است.');
  const count=await db().prepare('SELECT COUNT(*) AS count FROM cart_items WHERE user_id = ?').bind(u.userId).first<{count:number}>();if((count?.count||0)>=50)fail('در هر سفارش حداکثر ۵۰ دوره انتخاب کن.');
  await db().prepare('INSERT INTO cart_items (user_id,course_id,created) VALUES (?,?,?) ON CONFLICT(user_id,course_id) DO NOTHING').bind(u.userId,id,Date.now()).run();return {ok:true};
 }
 if(b.action==='cancelCheckout'){
  await db().prepare("UPDATE orders SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'draft'").bind(clean(b.orderId),u.userId).run();return {ok:true};
 }
 if(b.action==='startCheckout'){
  const existing=await draft(u.userId);if(existing)return {id:existing.id};
  const cart=(await db().prepare('SELECT c.id,c.title,c.price FROM cart_items i JOIN courses c ON c.id = i.course_id WHERE i.user_id = ? ORDER BY i.created').bind(u.userId).all<{id:string;title:string;price:number|null}>()).results;
  if(!cart.length||cart.length>50)fail('سبد خرید باید بین ۱ تا ۵۰ دوره داشته باشد.');
  for(const c of cart){if(c.price===null)fail('قیمت یکی از دوره‌ها هنوز تعیین نشده است.');if(await hasAccess(u.userId,c.id))fail('یکی از دوره‌ها از قبل فعال است؛ آن را از سبد حذف کن.');if(await db().prepare("SELECT 1 FROM order_items i JOIN orders o ON o.id = i.order_id WHERE o.user_id = ? AND i.course_id = ? AND o.status = 'pending'").bind(u.userId,c.id).first())fail('یکی از دوره‌ها منتظر بررسی مالی است؛ آن را از سبد حذف کن.');}
  const expected=b.items;if(!Array.isArray(expected)||expected.length!==cart.length||cart.some(c=>!expected.some(e=>e&&typeof e==='object'&&e.id===c.id&&e.price===c.price)))fail('سبد یا قیمت‌ها تغییر کرده‌اند؛ سبد را به‌روز کن و دوباره ادامه بده.',409);
  const payment=await paymentDetails();if(!payment.cardNumber||!payment.cardOwner)fail('مشخصات واریز هنوز توسط مدیر ثبت نشده است.');
  const id=crypto.randomUUID(),total=cart.reduce((sum,c)=>sum+c.price!,0);
  const queries=[db().prepare('INSERT INTO orders (id,user_id,buyer_name,buyer_username,total,status,payment_card,payment_owner,created) VALUES (?,?,?,?,?,?,?,?,?)').bind(id,u.userId,u.displayName,u.username||u.email,total,'draft',payment.cardNumber,payment.cardOwner,Date.now())];
  for(const c of cart)queries.push(db().prepare('INSERT INTO order_items (order_id,course_id,title,price) VALUES (?,?,?,?)').bind(id,c.id,c.title,c.price));
  try{await db().batch(queries);}catch(e){const simultaneous=await draft(u.userId);if(simultaneous)return {id:simultaneous.id};throw e;}
  return {id};
 }
 fail('درخواست معتبر نیست.');
}
async function boundedBody(req:Request){
 const max=6*1024**2;if(Number(req.headers.get('content-length'))>max)fail('حجم درخواست بیش از حد مجاز است.',413);
 if(!req.body)fail('رسید را ارسال کن.');const reader=req.body.getReader(),chunks:Uint8Array[]=[];let size=0;
 for(;;){const next=await reader.read();if(next.done)break;size+=next.value.byteLength;if(size>max){await reader.cancel();fail('حجم درخواست بیش از حد مجاز است.',413);}chunks.push(next.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 return new Request(req.url,{method:'POST',headers:req.headers,body:bytes}).formData();
}
function imageMime(bytes:Uint8Array){
 if(bytes.length>=8&&[137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n))return 'image/png';
 if(bytes.length>=3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'image/jpeg';
 if(bytes.length>=12&&new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP')return 'image/webp';
 fail('فیش را به صورت عکس JPG، PNG یا WebP ارسال کن.');
}
export async function submitReceipt(req:Request){
 const u=await shopStudent();const id=clean(new URL(req.url).searchParams.get('order'));
 const order=await db().prepare('SELECT status FROM orders WHERE id = ? AND user_id = ?').bind(id,u.userId).first<{status:string}>();if(!order)fail('سفارش پیدا نشد.',404);
 if(order.status==='pending')return {ok:true,already:true};if(order.status!=='draft')fail('این سفارش قابل ارسال نیست.',409);
 const form=await boundedBody(req);const text=form.get('text');if(text!==null&&typeof text!=='string')fail('متن رسید معتبر نیست.');const receiptText=typeof text==='string'?text.trim():'';if(receiptText.length>4000)fail('متن رسید حداکثر ۴۰۰۰ کاراکتر باشد.');
 const file=form.get('image');let key:string|null=null,mime:string|null=null,size:number|null=null,bytes:Uint8Array|null=null;
 if(file!==null&&typeof file==='string')fail('عکس رسید معتبر نیست.');
 if(file&&typeof file!=='string'&&file.size){if(file.size>5*1024**2)fail('عکس رسید حداکثر ۵ مگابایت باشد.',413);bytes=new Uint8Array(await file.arrayBuffer());mime=imageMime(bytes);size=bytes.length;key='receipts/'+crypto.randomUUID();}
 if(!receiptText&&!bytes)fail('عکس فیش یا متن اطلاعات واریز را وارد کن.');
 if(key&&bytes)await bucket().put(key,bytes,{httpMetadata:{contentType:mime!}});
 try{
  const result=await db().batch([
   db().prepare("UPDATE orders SET status = 'pending',receipt_text = ?,receipt_key = ?,receipt_mime = ?,receipt_size = ?,submitted = ? WHERE id = ? AND user_id = ? AND status = 'draft'").bind(receiptText,key,mime,size,Date.now(),id,u.userId),
   db().prepare("DELETE FROM cart_items WHERE user_id = ? AND course_id IN (SELECT course_id FROM order_items WHERE order_id = ?) AND EXISTS (SELECT 1 FROM orders WHERE id = ? AND status = 'pending')").bind(u.userId,id,id)
  ]);
  if(!result[0].meta.changes){if(key)await bucket().delete(key);const current=await db().prepare('SELECT status FROM orders WHERE id = ? AND user_id = ?').bind(id,u.userId).first<{status:string}>();if(current?.status==='pending')return {ok:true,already:true};fail('وضعیت سفارش تغییر کرده است؛ صفحه را به‌روز کن.',409);}
  return {ok:true};
 }catch(e){if(key)await bucket().delete(key);throw e;}
}
