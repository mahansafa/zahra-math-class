export type StudentSummary = {
  id:string; username:string; name:string; active:number; must_change:number;
  first_name:string; last_name:string; national_id:string|null; phone:string;
  registration_source:string;
};

export function latinDigits(value:string){
  return value.replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c)))
    .replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
}

export function studentProfile(body:Record<string,unknown>){
  function name(value:unknown,label:string){
    if(typeof value!=='string')throw new Error(`${label} را وارد کن.`);
    const s=value.trim().replace(/\s+/g,' ');
    if(!s||s.length>60||/[\u0000-\u001f\u007f]/.test(s))throw new Error(`${label} باید بین ۱ تا ۶۰ کاراکتر باشد.`);
    return s;
  }
  const firstName=name(body.firstName,'نام'),lastName=name(body.lastName,'نام خانوادگی');
  const fullName=firstName+' '+lastName;
  if(fullName.length>120)throw new Error('نام و نام خانوادگی بیش از حد طولانی است.');
  const nationalId=typeof body.nationalId==='string'?latinDigits(body.nationalId.trim()):'';
  if(!/^\d{10}$/.test(nationalId)||/^(\d)\1{9}$/.test(nationalId))throw new Error('کد ملی را به‌صورت ۱۰ رقم وارد کن.');
  const phone=body.phone===undefined?'':typeof body.phone==='string'?latinDigits(body.phone.trim()):null;
  if(phone===null||(phone!==''&&!/^09\d{9}$/.test(phone)))throw new Error('شماره موبایل باید ۱۱ رقم باشد و با ۰۹ شروع شود.');
  return {firstName,lastName,fullName,nationalId,phone};
}
