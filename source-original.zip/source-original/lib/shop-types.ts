export type ShopCourse={id:string;title:string;description:string;price:number|null;lesson_count:number};
export type OrderItem={course_id:string;title:string;price:number};
export type OrderStatus='draft'|'pending'|'approved'|'rejected'|'cancelled';
export type ShopOrder={id:string;user_id:string;buyer_name:string;buyer_username:string;total:number;status:OrderStatus;payment_card:string;payment_owner:string;receipt_text:string;hasReceipt:boolean;review_note:string;created:number;submitted:number|null;reviewed:number|null;items:OrderItem[]};
export type PaymentDetails={cardNumber:string;cardOwner:string};
export type ShopData={courses:ShopCourse[];cart:string[];owned:string[];pending:string[];orders:ShopOrder[];payment:PaymentDetails;isAdmin:boolean};
export type ShopViewer={id:string;name:string;kind:'teacher'|'student';mustChange:boolean}|null;
