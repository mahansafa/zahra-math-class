import { db } from '@/lib/classroom';
import { digest,password,passwordRecord,username } from '@/lib/student-auth';
import { studentProfile } from '@/lib/student-profile';

export class RegistrationError extends Error {
  constructor(message:string,public status:number,public code?:string){super(message);}
}

export async function authBody(req:Request):Promise<Record<string,unknown>>{
  const reader=req.body?.getReader();
  if(!reader)throw new Error('درخواست معتبر نیست.');
  const chunks:Uint8Array[]=[];let size=0;
  try{
    while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;
      if(size>8192){await reader.cancel();throw new RegistrationError('حجم اطلاعات بیش از حد مجاز است.',413);}
      chunks.push(value);
    }
  }finally{reader.releaseLock();}
  const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}
  let body:unknown;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{throw new Error('درخواست معتبر نیست.');}
  if(!body||typeof body!=='object'||Array.isArray(body))throw new Error('درخواست معتبر نیست.');
  return body as Record<string,unknown>;
}

export async function registerStudent(body:Record<string,unknown>,ip:string){
  const now=Date.now(),key='signup:ip:'+ip;
  await db().prepare('INSERT INTO login_limits (key,attempts,reset) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN reset < ? THEN 1 ELSE attempts+1 END, reset=CASE WHEN reset < ? THEN ? ELSE reset END')
    .bind(key,1,now+15*60000,now,now,now+15*60000).run();
  const limit=await db().prepare('SELECT attempts FROM login_limits WHERE key = ?').bind(key).first<{attempts:number}>();
  if((limit?.attempts||0)>10)throw new RegistrationError('تعداد تلاش‌های ثبت‌نام زیاد شده است. ۱۵ دقیقه بعد دوباره امتحان کن.',429);
  const login=username(body.username),p=password(body.password),profile=studentProfile(body);
  if(p!==body.confirmPassword)throw new Error('تکرار رمز عبور یکسان نیست.');
  const taken=()=>new RegistrationError('این نام کاربری قبلاً استفاده شده است؛ نام دیگری انتخاب کن یا وارد حسابت شو.',409,'username_taken');
  if(await db().prepare('SELECT id FROM students WHERE username = ?').bind(login).first())throw taken();
  const record=await passwordRecord(p),id='student:'+crypto.randomUUID();
  const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
  try{
    await db().batch([
      db().prepare('INSERT INTO students (id,username,name,first_name,last_name,national_id,phone,registration_source,password_hash,salt,active,must_change,created) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .bind(id,login,profile.fullName,profile.firstName,profile.lastName,profile.nationalId,profile.phone,'self',record.passwordHash,record.salt,1,0,now),
      db().prepare('INSERT INTO sessions (token_hash,user_id,expires) VALUES (?,?,?)').bind(await digest(token),id,now+7*86400000)
    ]);
  }catch{
    if(await db().prepare('SELECT id FROM students WHERE username = ?').bind(login).first())throw taken();
    throw new RegistrationError('ساخت حساب موقتاً انجام نشد. دوباره امتحان کن.',503);
  }
  return {id,username:login,token};
}
