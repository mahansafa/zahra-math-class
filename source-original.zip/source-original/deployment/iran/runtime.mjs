import { DatabaseSync, backup } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream, createWriteStream, mkdirSync, readFileSync, readdirSync } from 'node:fs';
import { readFile, writeFile, stat, rename, unlink, rm, mkdir } from 'node:fs/promises';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import path from 'node:path';

// Node-only adapter. It is copied into the independent Linux application;
// the existing Cloudflare Worker never imports this module.
export class SQLiteDatabase {
  constructor(filename, migrationDir) {
    mkdirSync(path.dirname(filename), { recursive: true, mode: 0o700 });
    this.native = new DatabaseSync(filename);
    this.native.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
    this.native.exec('CREATE TABLE IF NOT EXISTS _iran_migrations (name TEXT PRIMARY KEY, sha TEXT NOT NULL)');
    if (migrationDir) this.migrate(migrationDir);
  }
  migrate(dir) {
    const files = readdirSync(dir).filter(f => /^\d{4}_.+\.sql$/.test(f)).sort();
    for (const name of files) {
      const sql = readFileSync(path.join(dir, name), 'utf8');
      const sha = createHash('sha256').update(sql).digest('hex');
      const previous = this.native.prepare('SELECT sha FROM _iran_migrations WHERE name=?').get(name);
      if (previous) {
        if (previous.sha !== sha) throw new Error('Applied migration changed: ' + name);
        continue;
      }
      this.native.exec('BEGIN IMMEDIATE');
      try {
        this.native.exec(sql);
        this.native.prepare('INSERT INTO _iran_migrations VALUES (?,?)').run(name, sha);
        this.native.exec('COMMIT');
      } catch (e) { this.native.exec('ROLLBACK'); throw e; }
    }
    this.native.exec(`CREATE TABLE IF NOT EXISTS iran_admins (
      id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
      email TEXT NOT NULL, password_hash TEXT NOT NULL, salt TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1);
      CREATE TABLE IF NOT EXISTS iran_admin_sessions (
      token_hash TEXT PRIMARY KEY, admin_id TEXT NOT NULL REFERENCES iran_admins(id), expires INTEGER NOT NULL);
      CREATE INDEX IF NOT EXISTS iran_admin_sessions_admin ON iran_admin_sessions(admin_id);`);
  }
  prepare(sql) { return new SQLiteStatement(this, sql); }
  async batch(statements) {
    this.native.exec('BEGIN IMMEDIATE');
    try {
      // Execute synchronously inside the transaction. Yielding between writes
      // would allow another request to enter this connection's transaction.
      const results = statements.map(s => {
        if (s.database !== this) throw new Error('Invalid transaction statement');
        return s.execute();
      });
      this.native.exec('COMMIT'); return results;
    } catch (e) { this.native.exec('ROLLBACK'); throw e; }
  }
  async backupTo(filename) { await backup(this.native, filename); }
  close() { this.native.close(); }
}
class SQLiteStatement {
  constructor(database, sql, values = []) { this.database = database; this.sql = sql; this.values = values; }
  bind(...values) { return new SQLiteStatement(this.database, this.sql, values); }
  statement() { return this.database.native.prepare(this.sql); }
  execute() {
    const statement = this.statement();
    let results = [], changes = 0;
    if (statement.columns().length) results = statement.all(...this.values);
    else changes = Number(statement.run(...this.values).changes);
    if (results.length) changes = Number(this.database.native.prepare('SELECT changes() AS changes').get().changes);
    return { success: true, results, meta: { changes, duration: 0 } };
  }
  async run() { return this.execute(); }
  async all() { return this.execute(); }
  async first(column) {
    const row = this.statement().get(...this.values);
    return row ? (column === undefined ? row : row[column]) : null;
  }
  async raw(options) {
    const statement = this.statement(); statement.setReturnArrays(true);
    const rows = statement.all(...this.values);
    return options?.columnNames ? [statement.columns().map(c => c.name), ...rows] : rows;
  }
}

const objectId = key => createHash('sha256').update(key).digest('hex');
const uploadIdPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
export class PrivateFileBucket {
  constructor(root) {
    this.root = path.resolve(root);
    mkdirSync(path.join(this.root, 'objects'), { recursive: true, mode: 0o700 });
    mkdirSync(path.join(this.root, 'multipart'), { recursive: true, mode: 0o700 });
  }
  paths(key) {
    if (typeof key !== 'string' || !key || key.length > 1024) throw new Error('Invalid object key');
    const base = path.join(this.root, 'objects', objectId(key));
    return { data: base + '.data', metadata: base + '.json' };
  }
  async head(key) {
    const p = this.paths(key);
    try {
      const metadata = JSON.parse(await readFile(p.metadata, 'utf8'));
      const info = await stat(p.data);
      if (metadata.key !== key || info.size !== metadata.size) throw new Error('Invalid object metadata');
      return { ...metadata, size: info.size, uploaded: new Date(metadata.uploaded),
        writeHttpMetadata(headers) { if (metadata.httpMetadata?.contentType) headers.set('Content-Type', metadata.httpMetadata.contentType); } };
    } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
  }
  async get(key, options = {}) {
    const object = await this.head(key); if (!object) return null;
    const offset = options.range?.offset ?? 0;
    const length = options.range?.length ?? object.size - offset;
    if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > object.size) throw new Error('Invalid range');
    const body = length ? Readable.toWeb(createReadStream(this.paths(key).data, { start: offset, end: offset + length - 1, highWaterMark: 64 * 1024 })) : new ReadableStream({ start(c) { c.close(); } });
    return { ...object, body };
  }
  async put(key, bytes, options = {}) {
    const data = Buffer.from(bytes); const p = this.paths(key); const temporary = p.data + '.' + randomUUID();
    await writeFile(temporary, data, { mode: 0o600 }); await rename(temporary, p.data);
    const metadata = { key, size: data.length, etag: createHash('sha256').update(data).digest('hex'), uploaded: Date.now(), httpMetadata: options.httpMetadata || {} };
    await this.saveMetadata(p.metadata, metadata); return metadata;
  }
  async saveMetadata(filename, metadata) {
    const temporary = filename + '.' + randomUUID();
    await writeFile(temporary, JSON.stringify(metadata), { mode: 0o600 }); await rename(temporary, filename);
  }
  async delete(key) {
    const p = this.paths(key);
    for (const filename of [p.data, p.metadata]) { try { await unlink(filename); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
  }
  async createMultipartUpload(key, options = {}) {
    this.paths(key); const uploadId = randomUUID(); const dir = path.join(this.root, 'multipart', uploadId);
    await mkdir(dir, { mode: 0o700 });
    await writeFile(path.join(dir, 'upload.json'), JSON.stringify({ key, httpMetadata: options.httpMetadata || {}, created: Date.now() }), { mode: 0o600 });
    return this.resumeMultipartUpload(key, uploadId);
  }
  resumeMultipartUpload(key, uploadId) {
    this.paths(key); if (!uploadIdPattern.test(uploadId)) throw new Error('Invalid upload ID');
    const bucket = this; const dir = path.join(this.root, 'multipart', uploadId);
    async function metadata() { const m = JSON.parse(await readFile(path.join(dir, 'upload.json'), 'utf8')); if (m.key !== key) throw new Error('Upload key mismatch'); return m; }
    return { key, uploadId,
      async uploadPart(partNumber, bytes) {
        await metadata(); const data = Buffer.from(bytes);
        if (!Number.isInteger(partNumber) || partNumber < 1 || partNumber > 256 || data.length > 8 * 1024 ** 2) throw new Error('Invalid upload part');
        const etag = createHash('sha256').update(data).digest('hex');
        await writeFile(path.join(dir, `part-${partNumber}-${etag}`), data, { mode: 0o600 });
        return { partNumber, etag };
      },
      async complete(parts) {
        const m = await metadata();
        if (!Array.isArray(parts) || !parts.length || parts.length > 256 || parts.some((p, i) => p.partNumber !== i + 1 || !/^[a-f0-9]{64}$/.test(p.etag))) throw new Error('Invalid multipart completion');
        const target = bucket.paths(key); const temporary = target.data + '.' + randomUUID(); const hash = createHash('sha256');
        let size = 0;
        try {
          // One bounded file stream at a time; never buffer a complete video.
          for (const p of parts) {
            const filename = path.join(dir, `part-${p.partNumber}-${p.etag}`);
            const partHash = createHash('sha256');
            for await (const chunk of createReadStream(filename)) { hash.update(chunk); partHash.update(chunk); size += chunk.length; }
            if (partHash.digest('hex') !== p.etag || size > 2 * 1024 ** 3) throw new Error('Upload part mismatch');
            await pipeline(createReadStream(filename), createWriteStream(temporary, { flags: 'a', mode: 0o600 }));
          }
          await rename(temporary, target.data);
          const result = { key, size, etag: hash.digest('hex'), uploaded: Date.now(), httpMetadata: m.httpMetadata };
          await bucket.saveMetadata(target.metadata, result); await rm(dir, { recursive: true }); return result;
        } catch (e) { try { await unlink(temporary); } catch {} throw e; }
      },
      async abort() { await metadata(); await rm(dir, { recursive: true }); },
    };
  }
}

let database, fileBucket;
const dataDir = () => path.resolve(process.env.DATA_DIR || '/var/lib/zahra-math');
export const env = {
  get DB() { return database ??= new SQLiteDatabase(path.join(dataDir(), 'classroom.sqlite'), path.resolve(process.env.MIGRATIONS_DIR || 'drizzle')); },
  get BUCKET() { return fileBucket ??= new PrivateFileBucket(path.join(dataDir(), 'private')); },
  get TEACHER_EMAIL() { return process.env.ADMIN_EMAIL; },
  get PUBLIC_ORIGIN() { return process.env.PUBLIC_ORIGIN; },
};
