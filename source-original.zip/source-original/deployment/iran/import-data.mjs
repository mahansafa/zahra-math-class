import { env } from './runtime.mjs';
import { readFileSync } from 'node:fs';
// Import only an authenticated export from the original classroom. Run before
// creating the local administrator, with the destination service stopped.
const allowed=['courses','students','settings','lessons','enrollments','cart_items','orders','order_items'];
const filename=process.argv[2];if(!filename)throw new Error('Provide an exported classroom JSON file');
const input=JSON.parse(readFileSync(filename,'utf8'));
if(input.format!=='zahra-math-export-v1'||!input.tables||typeof input.tables!=='object')throw new Error('Unsupported export format');
const db=env.DB;
for(const table of allowed)if((await db.prepare(`SELECT COUNT(*) AS count FROM ${table}`).first()).count)throw new Error('Import requires an empty destination; existing records were preserved');
const queries=[];
for(const table of allowed) {
  const columns=new Set(db.native.prepare(`PRAGMA table_info(${table})`).all().map(c=>c.name));
  const rows=input.tables[table]??[];if(!Array.isArray(rows))throw new Error('Invalid table '+table);
  for(const row of rows) {
    if(!row||typeof row!=='object'||Array.isArray(row))throw new Error('Invalid row');
    const names=Object.keys(row);if(!names.length||names.some(c=>!columns.has(c)))throw new Error('Unknown column in '+table);
    queries.push(db.prepare(`INSERT INTO ${table} (${names.map(c=>'"'+c+'"').join(',')}) VALUES (${names.map(()=>'?').join(',')})`).bind(...names.map(c=>row[c])));
  }
}
await db.batch(queries);db.close();
console.log('Accounts, course access and purchases imported. Old login sessions, device locks, leases and unfinished uploads are intentionally not imported. Copy private video and receipt objects separately before launch.');
