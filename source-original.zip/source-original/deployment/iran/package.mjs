import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, readlinkSync, symlinkSync, lstatSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const app=path.resolve(process.argv[2]||path.join(here,'../../work/iran-app'));
const output=path.resolve(process.argv[3]||path.join(here,'../../work/iran-release'));
if(existsSync(output)&&readdirSync(output).length)throw new Error('Release directory must be empty');
mkdirSync(output,{recursive:true});
const manifest=JSON.parse(readFileSync(path.join(app,'.next/required-server-files.json'),'utf8'));
const standalone=path.join(app,'.next/standalone');
const relative=path.relative(manifest.config.outputFileTracingRoot||app,app);
if(relative.startsWith('..')||path.isAbsolute(relative))throw new Error('Invalid standalone tracing root');
const built=path.join(standalone,relative);
const application=path.join(output,'app');mkdirSync(application);
for(const name of ['.next','server.js','package.json'])cpSync(path.join(built,name),path.join(application,name),{recursive:true});
const modules=path.join(application,'node_modules');
cpSync(path.join(standalone,'node_modules'),modules,{recursive:true,dereference:false,verbatimSymlinks:true});
// In this workspace dependencies are linked from the original checkout. Keep
// only the traced runtime files, and recreate their package links within the
// release rather than copying that external node_modules directory.
function linkPackage(name) {
  const source=path.join(app,'node_modules',name),target=path.join(modules,name);
  if(existsSync(target)||!lstatSync(source,{throwIfNoEntry:false})?.isSymbolicLink())return;
  const link=readlinkSync(source);
  if(path.isAbsolute(link)||!existsSync(path.resolve(path.dirname(target),link)))return;
  mkdirSync(path.dirname(target),{recursive:true});symlinkSync(link,target);
}
for(const entry of readdirSync(path.join(app,'node_modules'))) {
  if(entry.startsWith('@'))for(const child of readdirSync(path.join(app,'node_modules',entry)))linkPackage(entry+'/'+child);
  else if(!entry.startsWith('.'))linkPackage(entry);
}
// Next.js standalone does not copy public assets or static bundles itself.
cpSync(path.join(app,'public'),path.join(output,'app/public'),{recursive:true});
cpSync(path.join(app,'.next/static'),path.join(output,'app/.next/static'),{recursive:true});
cpSync(path.join(app,'drizzle'),path.join(output,'app/drizzle'),{recursive:true});
mkdirSync(path.join(output,'operations'));
for(const name of ['runtime.mjs','configure-admin.mjs','backup.mjs','import-data.mjs','install.sh','nginx.conf.template','zahra-math.service','zahra-math-backup.service','zahra-math-backup.timer','README.md'])cpSync(path.join(here,name),path.join(output,'operations',name));
const nodeDir=path.join(output,'node');mkdirSync(nodeDir);cpSync(process.execPath,path.join(nodeDir,'node'));
if(!existsSync(path.join(output,'app/server.js')))throw new Error('Expected standalone server.js at the application root; review output tracing');
console.log('Prepared release at '+output+' (includes Linux Node binary; confirm target OS and architecture before installing).');
