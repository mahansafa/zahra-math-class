import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { mkdtemp, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { randomBytes, createHash } from 'node:crypto';
import path from 'node:path';
import { SQLiteDatabase } from './runtime.mjs';
const release=path.resolve(process.argv[2]||new URL('../../work/iran-release',import.meta.url).pathname);
const root=await mkdtemp(tmpdir()+'/iran-server-');
const origin='http://127.0.0.1:4317';
const settings={...process.env,DATA_DIR:root,ADMIN_EMAIL:'teacher@example.test',PUBLIC_ORIGIN:origin,MIGRATIONS_DIR:path.join(release,'app/drizzle'),NODE_ENV:'production',NEXT_TELEMETRY_DISABLED:'1',HOSTNAME:'127.0.0.1',PORT:'4317'};
const db=new SQLiteDatabase(root+'/classroom.sqlite',settings.MIGRATIONS_DIR);
const previousOwner='owner-before-iran-migration';
await db.prepare("INSERT INTO settings VALUES ('owner',?)").bind(previousOwner).run();
const adminPassword=randomBytes(24).toString('hex');
const configured=spawnSync(path.join(release,'node/node'),[path.join(release,'operations/configure-admin.mjs'),'--stdin-json'],{env:settings,input:JSON.stringify({username:'teacher',name:'مدرس آزمایشی',password:adminPassword}),encoding:'utf8'});
assert.equal(configured.status,0,configured.stderr);
assert.equal((await db.prepare('SELECT id FROM iran_admins').first()).id,previousOwner);
let log='';
const server=spawn(path.join(release,'node/node'),['server.js'],{cwd:path.join(release,'app'),env:settings,stdio:['ignore','pipe','pipe']});
server.stdout.on('data',v=>{log+=v});server.stderr.on('data',v=>{log+=v});
let assertions=0;
function check(value,message){assert(value,message);assertions++;}
async function request(route,body,cookie,extra={}) {
  const response=await fetch(origin+route,{method:body===undefined?'GET':'POST',headers:{...(body===undefined?{}:{'Content-Type':'application/json',Origin:origin}),...(cookie?{Cookie:cookie}:{}),...extra},...(body===undefined?{}:{body:JSON.stringify(body)})});
  let data;try{data=await response.json();}catch{}
  return {response,data,cookie:response.headers.get('set-cookie')?.split(';')[0]};
}
async function post(route,body,cookie) {const r=await request(route,body,cookie);check(r.response.ok,r.data?.error||route);return r;}
try {
  for(let i=0;i<80;i++) {
    if(server.exitCode!==null)throw new Error(log);
    try{if((await fetch(origin+'/store')).ok)break;}catch{}
    await new Promise(r=>setTimeout(r,100));
    if(i===79)throw new Error('Server failed to start: '+log);
  }
  for(const route of ['/','/login','/register','/admin-login','/store','/cart','/finance','/fonts/bnazanin.ttf'])check((await fetch(origin+route)).ok,'Page/asset '+route);
  const spoof=await request('/api/shop',undefined,undefined,{'oai-authenticated-user-id':previousOwner,'oai-authenticated-user-email':settings.ADMIN_EMAIL});
  check(spoof.data?.isAdmin===false,'Forged ChatGPT headers cannot make an administrator');
  const wrong=await request('/api/admin-auth',{action:'login',username:'teacher',password:'incorrect'});check(wrong.response.status===401,'Incorrect administrator password');
  const admin=await post('/api/admin-auth',{action:'login',username:'teacher',password:adminPassword});
  check(/HttpOnly/.test(admin.response.headers.get('set-cookie'))&&/Secure/.test(admin.response.headers.get('set-cookie'))&&/SameSite=Strict/.test(admin.response.headers.get('set-cookie')),'Administrator cookie flags');
  const courseA=(await post('/api/classroom',{action:'createCourse',title:'دوره الف'},admin.cookie)).data.id;
  const courseB=(await post('/api/classroom',{action:'createCourse',title:'دوره ب'},admin.cookie)).data.id;
  await post('/api/shop',{action:'setPrice',courseId:courseA,price:250000},admin.cookie);
  await post('/api/shop',{action:'setPrice',courseId:courseB,price:175000},admin.cookie);
  await post('/api/shop',{action:'setPayment',cardNumber:'6037991234567890',cardOwner:'مدرس آزمایشی'},admin.cookie);
  const studentPassword=randomBytes(20).toString('hex');
  const student=await post('/api/auth',{action:'register',username:'studentone',password:studentPassword,confirmPassword:studentPassword,firstName:'دانش',lastName:'آموز',nationalId:'1234567890',role:'teacher',courseIds:[courseA]});
  check(student.response.status===201,'Student registration');
  const publicStudent=(await request('/api/classroom',undefined,student.cookie)).data;
  check(publicStudent.isAdmin===false&&publicStudent.students.length===0,'Student profile privacy');
  check(publicStudent.enrollments.length===0,'Registration cannot grant access');
  const adminSnapshot=(await request('/api/classroom',undefined,admin.cookie)).data;
  check(adminSnapshot.students.some(s=>s.id===student.data.id&&s.registration_source==='self'),'Student appears in teacher list');
  const denied=await request('/api/classroom',{action:'createCourse',title:'غیرمجاز'},student.cookie);check(!denied.response.ok,'Students cannot manage courses');
  const crossOrigin=await request('/api/shop',{action:'setPrice',courseId:courseA,price:1},admin.cookie,{Origin:'https://wrong.example'});check(!crossOrigin.response.ok,'Cross-origin requests denied');
  await post('/api/classroom',{action:'createStudent',name:'شاگرد دستی',username:'manualstudent',password:randomBytes(20).toString('hex'),courseIds:[courseB]},admin.cookie);
  const manual=(await db.prepare("SELECT id,must_change FROM students WHERE username='manualstudent'").first());check(manual.must_change===1,'Manual accounts still require initial password change');
  check((await db.prepare('SELECT status FROM enrollments WHERE user_id=? AND course_id=?').bind(manual.id,courseB).first()).status==='approved','Manual course access preserved');
  const video=Buffer.alloc(256*1024,7);video.write('ftypmp42',4);
  const upload=(await post('/api/classroom',{action:'startUpload',courseId:courseA,title:'کلاس نمونه',mime:'video/mp4',size:video.length},admin.cookie)).data.id;
  const partResponse=await fetch(origin+'/api/classroom?upload='+upload+'&part=1',{method:'PUT',headers:{Origin:origin,Cookie:admin.cookie,'Content-Type':'application/octet-stream'},body:video});
  check(partResponse.ok,'Upload video part');
  const part=await partResponse.json();
  const lesson=(await post('/api/classroom',{action:'completeUpload',id:upload,parts:[part]},admin.cookie)).data.id;
  const playback={action:'startPlayback',lessonId:lesson,token:'student-playback-token',device:'student-device'};
  check((await request('/api/classroom',playback,student.cookie)).response.status===403,'No video access before approval');
  await post('/api/shop',{action:'addCart',courseId:courseA},student.cookie);await post('/api/shop',{action:'addCart',courseId:courseB},student.cookie);
  const order=(await post('/api/shop',{action:'startCheckout',items:[{id:courseA,price:250000},{id:courseB,price:175000}]},student.cookie)).data.id;
  check((await db.prepare('SELECT total FROM orders WHERE id=?').bind(order).first()).total===425000,'Server-side sum');
  const empty=new FormData();empty.set('text',' ');
  check(!(await fetch(origin+'/api/shop?action=receipt&order='+order,{method:'POST',headers:{Origin:origin,Cookie:student.cookie},body:empty})).ok,'Empty receipt rejected');
  const evidence=new FormData();evidence.set('text','شماره پیگیری آزمایشی');
  const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j4x0AAAAASUVORK5CYII=','base64');
  evidence.set('image',new Blob([png],{type:'image/png'}),'receipt.png');
  check((await fetch(origin+'/api/shop?action=receipt&order='+order,{method:'POST',headers:{Origin:origin,Cookie:student.cookie},body:evidence})).ok,'Submit receipt');
  check((await request('/api/classroom',playback,student.cookie)).response.status===403,'Pending purchase cannot watch');
  const receipt=await fetch(origin+'/api/receipt?order='+order,{headers:{Cookie:admin.cookie}});check(receipt.ok&&Buffer.from(await receipt.arrayBuffer()).equals(png),'Private receipt reaches finance');
  check(!(await fetch(origin+'/api/receipt?order='+order)).ok,'Anonymous receipt blocked');
  await post('/api/shop',{action:'reviewOrder',orderId:order,decision:'approved'},admin.cookie);
  const playbackResult=await post('/api/classroom',playback,student.cookie);
  const range=await fetch(origin+playbackResult.data.url,{headers:{Cookie:student.cookie,Range:'bytes=10-29'}});
  check(range.status===206&&Buffer.from(await range.arrayBuffer()).equals(video.subarray(10,30)),'Authenticated range playback');
  const secondDevice=await request('/api/classroom',{...playback,device:'different-device',token:'different-token'},student.cookie);check(secondDevice.response.status===403,'Second device denied');
  const secondPlayback=await request('/api/classroom',{...playback,token:'different-token'},student.cookie);check(secondPlayback.response.status===409,'Concurrent playback from same account denied');
  check(!(await fetch(origin+playbackResult.data.url)).ok,'Anonymous video blocked');
  await post('/api/classroom',{action:'setStudentCourses',userId:student.data.id,courseIds:[courseB]},admin.cookie);
  await post('/api/shop',{action:'reviewOrder',orderId:order,decision:'approved'},admin.cookie);
  check((await request('/api/classroom',playback,student.cookie)).response.status===403,'Approval retry does not restore manually revoked access');
  const queries=[],viewers=[];
  for(let i=0;i<200;i++) {
    const id='load-student-'+i,token=randomBytes(32).toString('hex'),hash=createHash('sha256').update(token).digest('hex');
    queries.push(db.prepare('INSERT INTO students (id,username,name,password_hash,salt,active,must_change,created) VALUES (?,?,?,?,?,1,0,?)').bind(id,'loaduser'+i,'Load viewer','not-a-password','test-salt',Date.now()));
    queries.push(db.prepare('INSERT INTO sessions VALUES (?,?,?)').bind(hash,id,Date.now()+60000));
    queries.push(db.prepare("INSERT INTO enrollments VALUES (?,?,?,?,'approved',?)").bind(id,courseA,'Load viewer','loaduser'+i,Date.now()));
    queries.push(db.prepare('INSERT INTO leases VALUES (?,?,?,?)').bind(id,'load-token-'+i,lesson,Date.now()+60000));
    viewers.push({cookie:'__Host-math-session='+token,url:'/api/video?lesson='+lesson+'&token=load-token-'+i});
  }
  await db.batch(queries);
  const streams=await Promise.all(viewers.map(async v=>{const r=await fetch(origin+v.url,{headers:{Cookie:v.cookie,Range:'bytes=0-4095'}});return r.status===206&&Buffer.from(await r.arrayBuffer()).equals(video.subarray(0,4096));}));
  check(streams.every(Boolean),'200 parallel authenticated range requests');
  await post('/api/admin-auth',{action:'logout'},admin.cookie);
  check(!(await request('/api/classroom',{action:'createCourse',title:'پس از خروج'},admin.cookie)).response.ok,'Administrator logout revokes session');
  const backupDir=root+'/backups';
  const backed=spawnSync(path.join(release,'node/node'),[path.join(release,'operations/backup.mjs')],{env:{...settings,BACKUP_DIR:backupDir},encoding:'utf8'});check(backed.status===0,backed.stderr);
  const backupFiles=await readdir(backupDir);check(backupFiles.length===1,'Backup file');
  const restored=new SQLiteDatabase(path.join(backupDir,backupFiles[0]),settings.MIGRATIONS_DIR);
  check((await restored.prepare('SELECT total FROM orders WHERE id=?').bind(order).first()).total===425000,'Purchase survives backup restore');restored.close();
  console.log(`${assertions} standalone API checks passed, including 200 parallel private range requests. This is a functional local check, not proof of the destination server's network capacity.`);
} finally {
  server.kill('SIGTERM');db.close();
}
