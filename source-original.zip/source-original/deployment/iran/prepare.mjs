import { cpSync, readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const source=path.resolve(here,'../..');
const destination=path.resolve(process.argv[2]||path.join(source,'work/iran-app'));
if(destination===source || source.startsWith(destination+path.sep)) throw new Error('Choose a separate application directory');
if(existsSync(destination)&&readdirSync(destination).length) throw new Error('Destination must be empty; existing files are preserved');
mkdirSync(destination,{recursive:true});
for(const name of ['app','components','hooks','lib','db','public','vendor','drizzle','package.json','pnpm-lock.yaml','tsconfig.json','postcss.config.mjs']) {
  if(existsSync(path.join(source,name)))cpSync(path.join(source,name),path.join(destination,name),{recursive:true});
}
const read=name=>readFileSync(path.join(destination,name),'utf8');
const write=(name,value)=>{mkdirSync(path.dirname(path.join(destination,name)),{recursive:true});writeFileSync(path.join(destination,name),value);};
for(const name of ['lib/classroom.ts','lib/student-auth.ts','db/index.ts'])write(name,read(name).replace(/from ["']cloudflare:workers["']/g,'from "@/lib/iran-runtime.mjs"'));
write('db/index.ts',read('db/index.ts').replace('drizzle(env.DB,','drizzle(env.DB as unknown as D1Database,'));
const classroom=read('lib/classroom.ts');
if(!classroom.includes('origin!==new URL(req.url).origin'))throw new Error('Origin validation changed; review the generator');
write('lib/classroom.ts',classroom.replace('origin!==new URL(req.url).origin','origin!==(env.PUBLIC_ORIGIN||new URL(req.url).origin)'));
write('lib/iran-runtime.mjs',readFileSync(path.join(here,'runtime.mjs'),'utf8'));
write('lib/iran-admin.ts',readFileSync(path.join(here,'admin-auth.ts.template'),'utf8'));
write('app/api/admin-auth/route.ts',readFileSync(path.join(here,'admin-route.ts.template'),'utf8'));
write('app/admin-login/page.tsx',readFileSync(path.join(here,'admin-page.tsx.template'),'utf8'));
write('app/chatgpt-auth.ts',`import { getAdminIdentity } from '@/lib/iran-admin';
import { redirect } from 'next/navigation';
export type ChatGPTUser={userId:string;displayName:string;email:string;fullName:string|null};
export const getChatGPTUser=getAdminIdentity;
export function chatGPTSignInPath(returnTo:string){return '/admin-login'+(returnTo==='/finance'?'?next=%2Ffinance':'');}
export function chatGPTSignOutPath(){return '/admin-login?logout=1';}
export async function requireChatGPTUser(returnTo:string){const user=await getAdminIdentity();if(user)return user;redirect(chatGPTSignInPath(returnTo));}
`);
for(const name of ['app/classroom.tsx','app/shop-client.tsx','app/login/page.tsx']) {
  write(name,read(name).replaceAll('/signin-with-chatgpt?return_to=%2Ffinance','/admin-login?next=%2Ffinance').replaceAll('/signin-with-chatgpt?return_to=%2F','/admin-login').replaceAll('/signout-with-chatgpt?return_to=%2F','/admin-login?logout=1'));
}
write('next.config.mjs',`export default {output:'standalone',poweredByHeader:false,experimental:{cpus:2},outputFileTracingIncludes:{'/*':['./drizzle/*.sql']}};\n`);
const ts=JSON.parse(read('tsconfig.json'));ts.exclude=['node_modules'];ts.include=['next-env.d.ts','**/*.ts','**/*.tsx','.next/types/**/*.ts','**/*.mts'];write('tsconfig.json',JSON.stringify(ts,null,2)+'\n');
const pkg=JSON.parse(read('package.json'));pkg.name='zahra-math-iran';pkg.engines={node:'>=24.0.0'};pkg.scripts={build:'next build --webpack',start:'node .next/standalone/server.js'};write('package.json',JSON.stringify(pkg,null,2)+'\n');
write('.env.example','PUBLIC_ORIGIN=https://YOUR_DOMAIN.ir\nADMIN_EMAIL=YOUR_ADMIN_EMAIL\nDATA_DIR=/var/lib/zahra-math\nMIGRATIONS_DIR=/opt/zahra-math/current/drizzle\n');
console.log('Prepared independent application at '+destination);
