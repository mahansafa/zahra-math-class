import { env } from './runtime.mjs';
import { randomUUID, pbkdf2Sync } from 'node:crypto';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';

async function readHiddenPassword() {
  if (!stdin.isTTY) throw new Error('Use --stdin-json for a secure automated input stream');
  stdout.write('Admin password (at least 16 characters): ');
  stdin.setRawMode(true); stdin.resume();
  return new Promise((resolve,reject)=>{
    let result='';
    const finish=(error)=>{stdin.off('data',listener);stdin.setRawMode(false);stdin.pause();stdout.write('\n');error?reject(error):resolve(result);};
    const listener=chunk=>{for(const char of chunk.toString('utf8')) {
      if(char==='\r'||char==='\n'){finish();return;}
      if(char==='\u0003'){finish(new Error('Cancelled'));return;}
      if(char==='\u007f'||char==='\b')result=result.slice(0,-1);
      else if(char>=' '&&result.length<128)result+=char;
    }};
    stdin.on('data',listener);
  });
}
let input;
if(process.argv.includes('--stdin-json')) {
  let value='';for await(const chunk of stdin){value+=chunk;if(Buffer.byteLength(value)>8192)throw new Error('Input too large');}input=JSON.parse(value);
}else {
  const rl=createInterface({input:stdin,output:stdout});
  const username=await rl.question('Admin username: ');const name=await rl.question('Admin display name: ');rl.close();
  input={username,name,password:await readHiddenPassword()};
}
const username=typeof input.username==='string'?input.username.trim().toLowerCase():'';
if(!/^[a-z0-9][a-z0-9._-]{2,39}$/.test(username)||typeof input.name!=='string'||!input.name.trim()||input.name.length>120||typeof input.password!=='string'||input.password.length<16||input.password.length>128)throw new Error('Invalid administrator details');
const email=process.env.ADMIN_EMAIL?.trim().toLowerCase();if(!email||!email.includes('@'))throw new Error('Set ADMIN_EMAIL first');
const db=env.DB;const owner=await db.prepare("SELECT value FROM settings WHERE key='owner'").first();
const id=owner?.value||'admin:'+randomUUID();const salt=randomUUID();const hash=pbkdf2Sync(input.password,salt,100000,32,'sha256').toString('hex');
await db.batch([
  db.prepare('INSERT INTO iran_admins (id,username,name,email,password_hash,salt,active) VALUES (?,?,?,?,?,?,1) ON CONFLICT(id) DO UPDATE SET username=excluded.username,name=excluded.name,email=excluded.email,password_hash=excluded.password_hash,salt=excluded.salt,active=1').bind(id,username,input.name.trim(),email,hash,salt),
  db.prepare("INSERT INTO settings (key,value) VALUES ('owner',?) ON CONFLICT(key) DO NOTHING").bind(id),
  db.prepare('DELETE FROM iran_admin_sessions').bind(),
]);
db.close();console.log('Administrator configured; previous administrator sessions revoked.');
