#!/usr/bin/env bash
set -euo pipefail
umask 077
if [[ "$EUID" -ne 0 ]]; then echo 'Run the installer as root.' >&2; exit 1; fi
if [[ $# -ne 2 ]]; then echo 'Usage: install.sh DOMAIN ADMIN_EMAIL' >&2; exit 1; fi
class_domain="$1"
admin_email="$2"
if [[ ! "$class_domain" =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.ir$ || "$class_domain" == *..* ]]; then echo 'A valid .ir domain is required.' >&2; exit 1; fi
if [[ ! "$admin_email" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then echo 'Invalid administrator email.' >&2; exit 1; fi
release_root="$(cd -- "$(dirname -- "$0")/.." && pwd)"
if [[ "$release_root" != /opt/zahra-math/current ]]; then echo 'Install the release at /opt/zahra-math/current first.' >&2; exit 1; fi
if ! command -v nginx >/dev/null || ! command -v certbot >/dev/null; then echo 'Install nginx, certbot and python3-certbot-nginx first.' >&2; exit 1; fi
if [[ -e /etc/zahra-math.env || -e /etc/nginx/sites-available/zahra-math ]]; then echo 'Existing configuration preserved; review before upgrading.' >&2; exit 1; fi
"$release_root/node/node" -e 'if(Number(process.versions.node.split(".")[0])<24)process.exit(1)'
id -u zahra-math >/dev/null 2>&1 || useradd --system --home-dir /var/lib/zahra-math --shell /usr/sbin/nologin zahra-math
install -d -m 700 -o zahra-math -g zahra-math /var/lib/zahra-math /var/backups/zahra-math
install -d -m 700 -o zahra-math -g zahra-math "$release_root/app/.next/cache"
cat > /etc/zahra-math.env <<EOF
PUBLIC_ORIGIN=https://$class_domain
ADMIN_EMAIL=$admin_email
DATA_DIR=/var/lib/zahra-math
MIGRATIONS_DIR=$release_root/app/drizzle
BACKUP_DIR=/var/backups/zahra-math
EOF
chmod 640 /etc/zahra-math.env
chown root:zahra-math /etc/zahra-math.env
sed "s/__DOMAIN__/$class_domain/g" "$release_root/operations/nginx.conf.template" > /etc/nginx/sites-available/zahra-math
ln -s /etc/nginx/sites-available/zahra-math /etc/nginx/sites-enabled/zahra-math
nginx -t
cp "$release_root/operations/zahra-math.service" "$release_root/operations/zahra-math-backup.service" "$release_root/operations/zahra-math-backup.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl reload nginx
echo 'Configuration installed. Import existing data and create the administrator before launch.'
echo 'Then issue TLS, enable the service and test access. The application was not started automatically.'
