# مهندس زهرا تعویذی — نسخهٔ اولیه

RTL Persian classroom for recorded mathematics lessons. Create courses, upload MP4/WebM in 8 MiB parts (2 GiB per video), approve enrollments, watch authenticated private videos with range requests and a moving visible watermark.

## Current boundaries

This is an owner-private Sites preview. Instructor identity uses platform sign-in and an explicit TEACHER_EMAIL allowlist from runtime configuration. Only this verified teacher can initialize the owner row. Students have independent username/password accounts. Instructor-created accounts require a password change on first login. Students can also register at /register in two steps: choose credentials, then provide first name, last name, a 10-digit national ID and an optional Iranian mobile number. Completing the form creates the account and session atomically, without granting course access. Self-selected passwords do not require an immediate change. Admins can select multiple courses with checkboxes during account creation or management, approve course access, reset passwords, reset the permitted device, and disable accounts. Saved unchecked courses lose approved access; a lease for a revoked course is deleted in the same database batch. Existing approvals appear checked when account management opens. Self-registered accounts automatically appear in the admin list, which refreshes every 30 seconds while the students tab is open and when it regains focus. Their profile fields are visible only in the instructor account list/management dialog. National IDs are format-checked and preserve leading zeroes; no government identity lookup, SMS verification, or national-ID uniqueness check is performed. Manual card-transfer purchases are available through the store, cart and financial review pages; no bank gateway or automatic bank verification is connected.

Passwords use per-account salts and WebCrypto PBKDF2-SHA-256 at 100,000 iterations (Cloudflare WebCrypto limit). Login/change-password attempts have persisted per-account and per-IP limits. Registration has a separate persisted per-IP limit of 10 attempts per 15 minutes and auth bodies are bounded to 8 KiB. Session cookies are opaque, HttpOnly, Secure, SameSite=Lax and expire in seven days; only a SHA-256 token digest is stored. Password resets, password changes and disabling accounts revoke prior sessions and playback leases. The server never returns password hashes or salts in account lists. Student creation credentials are visible in the confirmation dialog only until it closes, not retrieved later.

The platform preview itself remains owner-private; student credentials do not bypass platform sharing restrictions. Public student launch requires an explicit sharing decision or migration to domestic hosting. No DRM or screen-recording protection is implemented. A DOM watermark and hidden download controls are deterrents only. Browser cookies represent devices and are copyable, not hardware binding. One live playback lease per account is renewed every 20 seconds and expires in 60 seconds. Access is checked at each video HTTP request; already-open responses are not stopped retroactively.

R2 is private: no public object links are emitted. Uploads and enrollment data persist in R2/D1. Large videos use bounded request chunks. The prototype does not transcode videos; H.264 MP4 is recommended. Failed uploads are aborted client-side; if the tab disappears during upload, unfinished multipart objects need operational cleanup. No paid service, domain, or Iran hosting has been purchased.

## Store and manual payment review

`/store` lists the same courses as the classroom. Only the instructor can set positive integer prices in toman or clear a price to disable purchases. Bank card number and holder name are configured by the instructor in the store or finance page; they start empty. Existing manual student creation and access controls remain available.

Each student's cart is persisted in D1, with one copy of each course. Checkout freezes course titles, prices, total and bank details in a draft order before the student pays. Server prices determine the total; a changed cart or stale price must be reviewed before checkout. A partial unique index limits each student to one draft. Cancelling an unpaid draft allows cart editing again.

Submission requires a nonblank payment description, a receipt image, or both. JPG/PNG/WebP receipts are limited to 5 MiB, with bounded multipart request reads and byte-signature MIME detection. Bytes are stored privately in R2; `/api/receipt` checks the order owner or the instructor on every request. Public object keys/URLs are not emitted. Image signature checks are not malware scanning or bank verification.

Submitting queues the order without granting access. The instructor reviews all submitted items and evidence at `/finance`; approval and the corresponding course grants use one D1 batch. Conditional updates and a per-decision nonce prevent conflicting simultaneous reviews or approval retries from granting courses twice or restoring a later manually revoked course. Rejection grants no new access and preserves unrelated manual enrollments. Student pages expose only the current student's cart, orders and review notes.

Changes to bank details or prices apply to future checkouts. Already created orders retain their recorded values. No transfer is initiated or verified automatically; the instructor must verify the actual bank deposit before approving. The private Sites audience remains unchanged and still blocks external students until the owner requests public sharing or domestic migration.

## Before launch in Iran

Move application hosting, database and private video storage to domestic infrastructure; preserve independent student authentication and provide a domestic instructor login; connect a chosen payment provider; integrate a DRM provider only after verifying domestic license issuance, browser/device compatibility and dependency access during international disconnection. Native Cloudflare bindings must be replaced with domestic database/object-storage adapters. A .ir domain alone is insufficient. Keep an explicit instructor allowlist on the target host. Use real video tests on students' target browsers. DRM protection and uninterrupted domestic access cannot be guaranteed universally.

## Independent Linux server preparation

`deployment/iran/README.md` documents the separate Iran-server build, independent administrator login, private streaming file storage, migration import, Nginx/systemd setup and database backups. `prepare.mjs` generates this variant without replacing the existing Cloudflare application. Production Next.js build and local standalone API tests passed, including 200 parallel authenticated range requests; destination network capacity and real 200-viewer playback remain unverified until a server is supplied. No destination server has been configured or live data moved yet.

## Development

Dependencies are managed with pnpm; retain its lockfile. Generate schema migrations with `pnpm db:generate`, use the Sites build script for production output, and apply each new local migration through Wrangler with `.wrangler/state`. Logical bindings: `DB`, `BUCKET`. No secrets required in this prototype. All writes require same-origin requests. Registration and login are unauthenticated; other mutations require authenticated server-side authorization.

## Fonts

B Nazanin regular is self-hosted as TTF from https://github.com/intuxicated/css-persian/blob/master/fonts/BNazanin.ttf . Bold WOFF2 is from https://github.com/artbijan/Web-Font/blob/master/BNazaninBold.woff2 . Font family metadata verifies regular as B Nazanin. No external font requests are required at runtime.

## Validation

TypeScript and production build passed. Worker integration tests cover instructor authorization, student creation, username uniqueness, password hashing, login, first-login password change, multi-course selection, access revocation and invalid-selection atomicity, playback access, concurrent playback, password reset/session revocation, disabling accounts, cross-origin rejection and login rate limits. Shop integration tests also cover cart isolation, server totals, frozen prices and bank details, receipt validation and privacy, approval/rejection, conflicting concurrent decisions, and preservation of manual access. Registration integration tests cover old-account migration, required profile fields, Persian/Arabic digit normalization, optional mobile, secure immediate login, automatic admin listing, profile privacy, privilege/access isolation, duplicate usernames including concurrent submissions, body/rate limits, and atomic rollback if session creation fails. The three suites pass 221 checks in total (58 auth, 96 shop, 67 registration). Browser interaction QA and WebMCP validation are unavailable in this environment.
