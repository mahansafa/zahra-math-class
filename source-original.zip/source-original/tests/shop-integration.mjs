import {createRequire} from 'node:module';
import fs from 'node:fs';
const root=process.cwd(),require=createRequire(root+'/package.json');
const {Miniflare}=require(require.resolve('miniflare',{paths:[require.resolve('wrangler/package.json')]}));
const files=fs.readdirSync(root+'/dist/server',{recursive:true}).filter(p=>/\.m?js$/.test(p));files.sort((a,b)=>a==='index.js'?-1:b==='index.js'?1:0);
const mf=new Miniflare({modules:files.map(p=>({type:'ESModule',path:root+'/dist/server/'+p})),modulesRoot:root+'/dist/server',compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],bindings:{TEACHER_EMAIL:'teacher@example.test'},d1Databases:{DB:'shop-test-db'},r2Buckets:{BUCKET:'shop-test-bucket'}});
const teacher={'oai-authenticated-user-id':'teacher-owner','oai-authenticated-user-email':'teacher@example.test',Origin:'http://test.local','Content-Type':'application/json'};
let checks=0;
function check(value,message){if(!value)throw new Error(message);checks++;console.log('PASS',message);}
async function post(path,body,headers=teacher,expected=200){const r=await mf.dispatchFetch('http://test.local'+path,{method:'POST',headers,body:JSON.stringify(body)});const j=await r.json();check(r.status===expected,body.action+' status '+r.status+(r.status!==expected?' '+j.error:''));return {data:j,cookie:r.headers.get('set-cookie')?.split(';')[0]};}
const shop=(body,headers,expected)=>post('/api/shop',body,headers,expected);
async function state(headers){const r=await mf.dispatchFetch('http://test.local/api/shop',{headers});check(r.status===200,'shop state loads');return r.json();}
async function receipt(orderId,text,bytes,headers,expected=200,type='image/png'){
 const form=new FormData();if(text!==undefined)form.set('text',text);if(bytes)form.set('image',new Blob([bytes],{type}),'receipt.png');
 const url='http://test.local/api/shop?action=receipt&order='+orderId;const encoded=new Request(url,{method:'POST',body:form});const r=await mf.dispatchFetch(url,{method:'POST',headers:{Origin:headers.Origin,Cookie:headers.Cookie,'Content-Type':encoded.headers.get('Content-Type')},body:await encoded.arrayBuffer()});const j=await r.json();check(r.status===expected,'receipt status '+r.status+(r.status!==expected?' '+j.error:''));return j;
}
try{
 const db=await mf.getD1Database('DB');for(const file of fs.readdirSync(root+'/drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of fs.readFileSync(root+'/drizzle/'+file,'utf8').split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql).run();
 await mf.dispatchFetch('http://test.local/',{headers:teacher});
 const a=(await post('/api/classroom',{action:'createCourse',title:'حسابان',description:'دوره حسابان'})).data;
 const b=(await post('/api/classroom',{action:'createCourse',title:'هندسه'})).data;
 const c=(await post('/api/classroom',{action:'createCourse',title:'دوره دستی'})).data;
 const s=(await post('/api/classroom',{action:'createStudent',name:'خریدار اول',username:'buyer.one',password:'test-initial-password',courseIds:[c.id]})).data;
 const s2=(await post('/api/classroom',{action:'createStudent',name:'خریدار دوم',username:'buyer.two',password:'test-initial-password',courseIds:[]})).data;
 async function login(name){const login=await post('/api/auth',{action:'login',username:name,password:'test-initial-password'});const headers={Origin:'http://test.local','Content-Type':'application/json',Cookie:login.cookie};const changed=await post('/api/auth',{action:'changePassword',currentPassword:'test-initial-password',newPassword:'test-personal-password'},headers);headers.Cookie=changed.cookie;return headers;}
 const first=await login('buyer.one'),second=await login('buyer.two');
 let catalog=await state(first);check(catalog.courses.length===3&&catalog.courses.every(c=>c.price===null),'existing courses automatically appear unpriced');
 await shop({action:'setPrice',courseId:a.id,price:1200000});await shop({action:'setPrice',courseId:b.id,price:800000});
 await shop({action:'setPrice',courseId:a.id,price:1},first,403);
 await shop({action:'setPrice',courseId:a.id,price:-1},teacher,400);
 await shop({action:'setPrice',courseId:a.id,price:0.5},teacher,400);
 await shop({action:'addCart',courseId:c.id},first,400);
 await shop({action:'addCart',courseId:a.id},first);await shop({action:'addCart',courseId:a.id},first);await shop({action:'addCart',courseId:b.id},first);
 catalog=await state(first);check(catalog.cart.length===2,'cart is durable and each course appears once');check((await state(second)).cart.length===0,'carts are isolated by student');
 const expected=[{id:a.id,price:1200000},{id:b.id,price:800000}];
 await shop({action:'startCheckout',items:expected},first,400);
 await shop({action:'setPayment',cardNumber:'1234',cardOwner:'مالک تست'},teacher,400);
 await shop({action:'setPayment',cardNumber:'۶۰۳۷ ۹۹۷۵ ۱۲۳۴ ۵۶۷۸',cardOwner:'مالک تست'});
 await shop({action:'setPayment',cardNumber:'6037997512345678',cardOwner:'غیرمجاز'},first,403);
 await shop({action:'startCheckout',items:[{id:a.id,price:1},{id:b.id,price:1}],total:2},first,409);
 const quote=(await shop({action:'startCheckout',items:expected,total:1},first)).data;
 const duplicate=(await shop({action:'startCheckout',items:expected},first)).data;check(duplicate.id===quote.id,'checkout retry reuses the frozen draft');
 let o=(await state(first)).orders.find(o=>o.id===quote.id);check(o.total===2000000&&o.items.length===2&&o.payment_card==='6037997512345678','server prices and normalized payment details are frozen');
 await shop({action:'setPrice',courseId:a.id,price:1500000});await shop({action:'setPayment',cardNumber:'6037997512345679',cardOwner:'مالک جدید'});
 o=(await state(first)).orders.find(o=>o.id===quote.id);check(o.total===2000000&&o.items.find(i=>i.course_id===a.id).price===1200000&&o.payment_owner==='مالک تست','later price and bank changes preserve the unpaid quote');
 await shop({action:'removeCart',courseId:a.id},first,409);
 const emptyReceipt=await receipt(quote.id,'   ',undefined,first,400);check(emptyReceipt.error.includes('عکس فیش یا متن'),'blank receipt receives the evidence-required error');check((await db.prepare('SELECT status FROM orders WHERE id = ?').bind(quote.id).first()).status==='draft','blank receipt cannot submit an order');
 await receipt(quote.id,'اطلاعات واریز',undefined,second,404);
 await shop({action:'reviewOrder',orderId:quote.id,decision:'approved'},teacher,409);
 await receipt(quote.id,'شماره پیگیری تست، مبلغ ۲۰۰۰۰۰۰ تومان',undefined,first);
 await receipt(quote.id,'',undefined,first);
 catalog=await state(first);check(catalog.cart.length===0&&catalog.orders.find(o=>o.id===quote.id).status==='pending','receipt submission clears cart and queues the order');
 let access=(await db.prepare('SELECT course_id FROM enrollments WHERE user_id = ? AND status = ?').bind(s.id,'approved').all()).results;
 check(access.length===1&&access[0].course_id===c.id,'submission grants no access and preserves manual enrollment');
 await shop({action:'reviewOrder',orderId:quote.id,decision:'approved'},first,403);
 await shop({action:'addCart',courseId:a.id},first,400);
 const admin=await state(teacher);check(admin.orders.some(o=>o.id===quote.id&&o.receipt_text.includes('پیگیری')&&o.items.length===2),'finance receives buyer, ordered courses and payment text');
 await shop({action:'reviewOrder',orderId:quote.id,decision:'approved',note:'واریز بررسی شد.'});
 access=(await db.prepare('SELECT course_id FROM enrollments WHERE user_id = ? AND status = ?').bind(s.id,'approved').all()).results;
 check(access.length===3&&[a.id,b.id,c.id].every(id=>access.some(e=>e.course_id===id)),'approval grants all purchased courses while preserving manual access');
 await post('/api/classroom',{action:'setEnrollment',userId:s.id,courseId:a.id,status:'pending'});
 await shop({action:'reviewOrder',orderId:quote.id,decision:'approved'});
 check((await db.prepare('SELECT status FROM enrollments WHERE user_id = ? AND course_id = ?').bind(s.id,a.id).first()).status==='pending','repeated approval cannot undo a later manual revocation');
 await shop({action:'reviewOrder',orderId:quote.id,decision:'rejected'},teacher,409);
 await shop({action:'addCart',courseId:a.id},second);await shop({action:'addCart',courseId:b.id},second);
 const order2=(await shop({action:'startCheckout',items:[{id:a.id,price:1500000},{id:b.id,price:800000}]},second)).data;
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j2xQAAAAASUVORK5CYII=','base64');
 await receipt(order2.id,undefined,Buffer.from('<svg onload="alert(1)"/>'),second,400,'image/svg+xml');
 await receipt(order2.id,undefined,png,second);
 o=(await state(second)).orders.find(o=>o.id===order2.id);check(o.hasReceipt&&!o.receipt_text,'image-only receipt is accepted');
 const url='http://test.local/api/receipt?order='+order2.id;
 for(const [headers,expectedStatus,label] of [[second,200,'receipt owner'],[teacher,200,'finance'],[first,404,'another student'],[{},401,'anonymous']]){const r=await mf.dispatchFetch(url,{headers});check(r.status===expectedStatus,'private receipt access for '+label);if(r.status===200)check(r.headers.get('Content-Type')==='image/png'&&(await r.arrayBuffer()).byteLength===png.length,'receipt bytes served with verified image MIME');}
 check(!(await state(first)).orders.some(o=>o.id===order2.id),'students cannot see another buyer order');
 await shop({action:'reviewOrder',orderId:order2.id,decision:'rejected',note:'اطلاعات فیش نیاز به پیگیری دارد.'});
 check(!(await db.prepare('SELECT course_id FROM enrollments WHERE user_id = ? AND status = ?').bind(s2.id,'approved').all()).results.length,'rejection grants no courses');
 check((await state(second)).orders.find(o=>o.id===order2.id).review_note.includes('پیگیری'),'rejection explanation reaches the buyer');
 await shop({action:'addCart',courseId:b.id},second);const revised=(await shop({action:'startCheckout',items:[{id:b.id,price:800000}]},second)).data;
 await shop({action:'cancelCheckout',orderId:revised.id},second);await shop({action:'removeCart',courseId:b.id},second);
 check((await state(second)).cart.length===0,'editing a draft allows cart changes');
 await shop({action:'addCart',courseId:b.id},second);const race=(await shop({action:'startCheckout',items:[{id:b.id,price:800000}]},second)).data;
 await receipt(race.id,'فیش متنی تست هم‌زمان',undefined,second);
 const raceResponses=await Promise.all(['approved','rejected'].map(decision=>mf.dispatchFetch('http://test.local/api/shop',{method:'POST',headers:teacher,body:JSON.stringify({action:'reviewOrder',orderId:race.id,decision})})));
 check(raceResponses.map(r=>r.status).sort().join()==='200,409','concurrent conflicting reviews have exactly one winner');
 const reviewed=await db.prepare('SELECT status FROM orders WHERE id = ?').bind(race.id).first();const enrollment=await db.prepare('SELECT status FROM enrollments WHERE user_id = ? AND course_id = ?').bind(s2.id,b.id).first();
 check((reviewed.status==='approved')===(enrollment?.status==='approved'),'course access agrees with the winning financial decision');
 await shop({action:'setPrice',courseId:a.id,price:null});check((await state(second)).courses.find(c=>c.id===a.id).price===null,'administrator can remove a price without deleting a course');
 await shop({action:'setPrice',courseId:a.id,price:1},{...teacher,Origin:'https://evil.test'},400);
 for(const route of ['/store','/cart','/finance']){const r=await mf.dispatchFetch('http://test.local'+route,{headers:teacher});check(r.status===200,'shop page serves '+route);}
 console.log('ALL',checks,'SHOP CHECKS PASSED');
}catch(e){process.exitCode=1;throw e;}finally{await mf.dispose();}
