import {createRequire} from 'node:module';
import fs from 'node:fs';
const root=process.cwd(),require=createRequire(root+'/package.json');
const {Miniflare}=require(require.resolve('miniflare',{paths:[require.resolve('wrangler/package.json')]}));
const files=fs.readdirSync(root+'/dist/server',{recursive:true}).filter(p=>/\.m?js$/.test(p));
files.sort((a,b)=>a==='index.js'?-1:b==='index.js'?1:0);
const mf=new Miniflare({modules:files.map(p=>({type:'ESModule',path:root+'/dist/server/'+p})),modulesRoot:root+'/dist/server',compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],bindings:{TEACHER_EMAIL:'teacher@example.test'},d1Databases:{DB:'signup-db'},r2Buckets:{BUCKET:'signup-bucket'}});
try{
  const db=await mf.getD1Database('DB');
  for(const file of fs.readdirSync(root+'/drizzle').filter(p=>p.endsWith('.sql')).sort()){
    if(file.startsWith('0003_'))await db.prepare('INSERT INTO students (id,username,name,password_hash,salt,active,must_change,created) VALUES (?,?,?,?,?,?,?,?)').bind('legacy','legacy.student','شاگرد قدیمی','legacy-hash','legacy-salt',1,1,1).run();
    for(const sql of fs.readFileSync(root+'/drizzle/'+file,'utf8').split('--> statement-breakpoint'))if(sql.trim())await db.prepare(sql).run();
  }
  let checks=0,ip=0;
  const check=(v,msg)=>{if(!v)throw new Error(msg);checks++;console.log('PASS',msg);};
  const headers={'Content-Type':'application/json',Origin:'http://test.local'};
  const teacher={...headers,'oai-authenticated-user-id':'teacher-owner','oai-authenticated-user-email':'teacher@example.test'};
  async function post(body,h={...headers,'cf-connecting-ip':'test-'+(++ip)},expected=201,path='/api/auth'){
    const r=await mf.dispatchFetch('http://test.local'+path,{method:'POST',headers:h,body:JSON.stringify(body)});
    const data=await r.json();check(r.status===expected,body.action+' returns '+expected);
    return {data,cookie:r.headers.get('set-cookie')?.split(';')[0],setCookie:r.headers.get('set-cookie')};
  }
  const legacy=await db.prepare('SELECT * FROM students WHERE id = ?').bind('legacy').first();
  check(legacy.name==='شاگرد قدیمی'&&legacy.registration_source==='admin'&&legacy.national_id===null&&legacy.phone==='','migration preserves existing accounts with optional profile defaults');
  await mf.dispatchFetch('http://test.local/',{headers:teacher});
  const course=(await post({action:'createCourse',title:'ریاضی'},teacher,200,'/api/classroom')).data;
  const base={action:'register',username:'Self.Student',password:'my-personal-test-password',confirmPassword:'my-personal-test-password',firstName:'  زهرا  ',lastName:'شاگرد',nationalId:'۰۰۱۲۳۴۵۶۷۸',phone:'۰۹۱۲۳۴۵۶۷۸۹'};
  await post(base,{...headers,Origin:'https://other.test'},400);
  for(const patch of [{firstName:''},{lastName:''},{firstName:'x'.repeat(61)},{nationalId:''},{nationalId:'123456789'},{nationalId:'12345678901'},{nationalId:'0000000000'},{nationalId:'12abc56789'},{phone:'12345678901'},{phone:123},{password:'short',confirmPassword:'short'},{confirmPassword:'different-password'},{username:'نام فارسی'}]){
    await post({...base,...patch},undefined,400);
  }
  check((await db.prepare('SELECT COUNT(*) AS n FROM students').first()).n===1,'invalid or cross-origin registration creates no partial accounts');
  const oversized=await mf.dispatchFetch('http://test.local/api/auth',{method:'POST',headers,body:JSON.stringify({...base,extra:'x'.repeat(9000)})});
  check(oversized.status===413,'actual request body limit enforced');
  const array=await mf.dispatchFetch('http://test.local/api/auth',{method:'POST',headers,body:'[]'});check(array.status===400,'non-object auth body rejected');
  const signup=await post({...base,role:'teacher',active:0,mustChange:true,courseIds:[course.id]});
  check(signup.cookie?.startsWith('__Host-math-session=')&&signup.setCookie.includes('HttpOnly')&&signup.setCookie.includes('Secure')&&signup.setCookie.includes('SameSite=Lax'),'self-registration issues protected login cookie');
  check(signup.data.mustChange===false&&!('password' in signup.data)&&!('nationalId' in signup.data)&&!('token' in signup.data),'registration response excludes credentials and profile');
  const stored=await db.prepare('SELECT * FROM students WHERE id = ?').bind(signup.data.id).first();
  check(stored.username==='self.student'&&stored.name==='زهرا شاگرد'&&stored.first_name==='زهرا'&&stored.last_name==='شاگرد','credentials and separate names saved and normalized');
  check(stored.national_id==='0012345678'&&stored.phone==='09123456789','Persian digits normalized and leading national-ID zeroes retained');
  check(stored.registration_source==='self'&&stored.active===1&&stored.must_change===0,'account is a regular self-registered student with personal password');
  check(stored.password_hash!==base.password&&stored.salt,'self-selected password salted and hashed');
  const sessions=(await db.prepare('SELECT * FROM sessions WHERE user_id = ?').bind(stored.id).all()).results;
  check(sessions.length===1&&sessions[0].token_hash!==signup.cookie.split('=')[1],'only digest of opaque session stored');
  check(!await db.prepare('SELECT 1 FROM enrollments WHERE user_id = ?').bind(stored.id).first(),'registration and client courseIds grant no course access');
  const student={...headers,Cookie:signup.cookie};
  const adminData=await (await mf.dispatchFetch('http://test.local/api/classroom',{headers:teacher})).json();
  const listed=adminData.students.find(s=>s.id===stored.id);
  check(listed?.name==='زهرا شاگرد'&&listed.national_id==='0012345678'&&listed.phone==='09123456789','self-registration automatically appears in admin account list with profile');
  check(!('password_hash' in listed)&&!('salt' in listed),'admin list contains no password records');
  const data=await (await mf.dispatchFetch('http://test.local/api/classroom',{headers:student})).json();
  check(!data.isAdmin&&data.students.length===0&&data.enrollments.length===0&&!JSON.stringify(data).includes('0012345678'),'student cannot see account list or private profile fields');
  const home=await mf.dispatchFetch('http://test.local/',{headers:student});const studentHtml=await home.text();
  check(home.status===200&&studentHtml.includes('زهرا شاگرد')&&!studentHtml.includes('پنل مدرس')&&!studentHtml.includes('0012345678'),'new session enters student panel without leaking national ID');
  await post({action:'createCourse',title:'غیرمجاز'},student,400,'/api/classroom');
  await db.prepare('INSERT INTO lessons (id,course_id,title,object_key,mime,size,position,created) VALUES (?,?,?,?,?,?,?,?)').bind('locked-lesson',course.id,'قفل','private-video','video/mp4',10,1,1).run();
  await post({action:'startPlayback',lessonId:'locked-lesson',token:'one',device:'one'},student,403,'/api/classroom');
  const finance=await mf.dispatchFetch('http://test.local/api/shop',{method:'POST',headers:student,body:JSON.stringify({action:'setPayment',cardNumber:'1234567890123456',cardOwner:'غیرمجاز'})});check(finance.status===403,'self-registered student has no financial administration permission');
  await post(base,undefined,409);
  const optional=await post({...base,username:'optional.student',nationalId:'١٢٣٤٥٦٧٨٩٠',phone:''});
  const optionalRow=await db.prepare('SELECT phone,national_id FROM students WHERE id = ?').bind(optional.data.id).first();check(optionalRow.phone===''&&optionalRow.national_id==='1234567890','mobile optional and Arabic digits accepted');
  const manual=(await post({action:'createStudent',name:'افزودهٔ دستی',username:'manual.student',password:'manual-initial-password',courseIds:[course.id]},teacher,200,'/api/classroom')).data;
  const manualRow=await db.prepare('SELECT * FROM students WHERE id = ?').bind(manual.id).first();
  check(manualRow.registration_source==='admin'&&manualRow.must_change===1&&manualRow.national_id===null,'manual account creation still works without new mandatory fields');
  check(!!await db.prepare("SELECT 1 FROM enrollments WHERE user_id = ? AND status='approved'").bind(manual.id).first(),'manual course grants preserved');
  await db.prepare("CREATE TRIGGER fail_signup_session BEFORE INSERT ON sessions WHEN (SELECT username FROM students WHERE id = NEW.user_id) = 'broken.batch' BEGIN SELECT RAISE(ABORT, 'test atomic session failure'); END").run();
  await post({...base,username:'broken.batch'},undefined,503);
  check(!await db.prepare("SELECT id FROM students WHERE username='broken.batch'").first(),'session failure rolls back account creation');
  await db.prepare('DROP TRIGGER fail_signup_session').run();
  const races=await Promise.all(['race-1','race-2'].map(async n=>{
    const r=await mf.dispatchFetch('http://test.local/api/auth',{method:'POST',headers:{...headers,'cf-connecting-ip':n},body:JSON.stringify({...base,username:'race.student'})});return r.status;
  }));
  check(races.sort().join(',')==='201,409','concurrent duplicate usernames create exactly one successful account');
  check((await db.prepare("SELECT COUNT(*) AS n FROM students WHERE username='race.student'").first()).n===1,'concurrent registration leaves one account');
  const limited={...headers,'cf-connecting-ip':'limited-signup'};
  for(let i=0;i<10;i++)await post({...base,firstName:''},limited,400);
  await post({...base,username:'blocked.by.limit'},limited,429);
  check(!await db.prepare("SELECT id FROM students WHERE username='blocked.by.limit'").first(),'registration rate limit creates no account');
  await post({action:'logout'},student,200);
  const gone=await mf.dispatchFetch('http://test.local/api/classroom',{headers:student});check(gone.status!==200,'logout revokes self-registration session');
  const login=await post({action:'login',username:'SELF.STUDENT',password:base.password},headers,200);
  check(login.data.mustChange===false&&!!login.cookie,'self-registered account can log back in with chosen password');
  for(const [path,needle] of [['/register','مشخصات شاگرد'],['/login','ثبت‌نام شاگرد'],['/store','ثبت‌نام']]){
    const page=await mf.dispatchFetch('http://test.local'+path);const html=await page.text();check(page.status===200&&html.includes(needle),'signup route/link served at '+path);
    check(!html.includes('0012345678')&&!html.includes('09123456789'),'anonymous page exposes no student identity at '+path);
  }
  console.log('ALL',checks,'CHECKS PASSED');
}catch(e){process.exitCode=1;throw e;}finally{await mf.dispose();}
