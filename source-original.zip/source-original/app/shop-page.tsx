import {currentIdentity} from '@/lib/student-auth';
import {shopSnapshot} from '@/lib/shop';
import ShopClient from './shop-client';
import type {ShopData} from '@/lib/shop-types';
export default async function ShopPage({mode}:{mode:'store'|'cart'|'finance'}){
 const u=await currentIdentity();let error='';let data:ShopData={courses:[],cart:[],owned:[],pending:[],orders:[],payment:{cardNumber:'',cardOwner:''},isAdmin:false};
 try{data=await shopSnapshot(u);}catch(e){console.error('shop page failed',e);error='اطلاعات فروشگاه موقتاً در دسترس نیست. دوباره تلاش کن.';}
 return <ShopClient mode={mode} initial={data} initialError={error} viewer={u?{id:u.userId,name:u.displayName,kind:u.kind,mustChange:u.mustChange}:null}/>;
}
