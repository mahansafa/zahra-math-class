import ShopPage from '../shop-page';
export const dynamic='force-dynamic';
export const metadata={title:'امور مالی | مهندس زهرا تعویذی'};
export default function Page(){return <ShopPage mode="finance"/>;}
