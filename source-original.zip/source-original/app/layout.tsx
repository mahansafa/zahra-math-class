import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'مهندس زهرا تعویذی',description:'کلاس‌های ضبط‌شدهٔ ریاضی مهندس زهرا تعویذی',icons:{icon:'/favicon.svg',shortcut:'/favicon.svg'},referrer:'no-referrer'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="fa" dir="rtl"><body>{children}</body></html>;}
