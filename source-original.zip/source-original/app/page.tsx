import { currentIdentity } from '@/lib/student-auth';
import { db,snapshot } from '@/lib/classroom';
import Classroom from './classroom';
export const dynamic='force-dynamic';
export default async function Page(){const user=await currentIdentity();let data:any={courses:[],lessons:[],enrollments:[],students:[],isAdmin:false};let error='';try{if(user?.kind==='teacher'){await db().prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO NOTHING').bind('owner',user.userId).run();}data=await snapshot(user?.userId);}catch(e){console.error('classroom load',e);error='اطلاعات کلاس‌ها موقتاً در دسترس نیست. دوباره تلاش کنید.';}return <Classroom initial={data} user={user?{id:user.userId,name:user.displayName,email:user.email,kind:user.kind,mustChange:user.mustChange}:null} initialError={error}/>;}
