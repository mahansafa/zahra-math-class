import ShopPage from '../shop-page';
export const dynamic='force-dynamic';
export const metadata={title:'سبد خرید | مهندس زهرا تعویذی'};
export default function Page(){return <ShopPage mode="cart"/>;}
