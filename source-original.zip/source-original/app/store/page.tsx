import ShopPage from '../shop-page';
export const dynamic='force-dynamic';
export const metadata={title:'فروشگاه دوره‌ها | مهندس زهرا تعویذی'};
export default function Page(){return <ShopPage mode="store"/>;}
