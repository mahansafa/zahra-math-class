'use client';
import {useState} from 'react';
import {Check,LoaderCircle,UserRound} from 'lucide-react';

export default function Register(){
  const [step,setStep]=useState(1),[username,setUsername]=useState(''),[password,setPassword]=useState(''),[confirm,setConfirm]=useState('');
  const [firstName,setFirstName]=useState(''),[lastName,setLastName]=useState(''),[nationalId,setNationalId]=useState(''),[phone,setPhone]=useState('');
  const [busy,setBusy]=useState(false),[error,setError]=useState('');
  function next(e:React.FormEvent){e.preventDefault();setError('');if(password!==confirm){setError('تکرار رمز عبور یکسان نیست.');return;}setStep(2);}
  async function register(e:React.FormEvent){
    e.preventDefault();setBusy(true);setError('');
    try{
      const r=await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'register',username,password,confirmPassword:confirm,firstName,lastName,nationalId,phone})});
      const j=await r.json() as {error?:string;code?:string};
      if(!r.ok){if(j.code==='username_taken')setStep(1);throw new Error(j.error||'ساخت حساب انجام نشد.');}
      const target=new URLSearchParams(location.search).get('next');
      location.href=target&&['/store','/cart'].includes(target)?target:'/';
    }catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  function loginHref(e:React.MouseEvent<HTMLAnchorElement>){
    e.preventDefault();const target=new URLSearchParams(location.search).get('next');
    location.href='/login'+(target&&['/store','/cart'].includes(target)?'?next='+encodeURIComponent(target):'');
  }
  return <main className="login-shell registration-shell">
    <a href="/" className="brand"><span className="brand-mark">∑</span><div><strong>مهندس زهرا تعویذی</strong><span>کلاس‌های ریاضی</span></div></a>
    <section className="login-card registration-card">
      <span className="section-icon"><UserRound/></span><h1>ساخت حساب شاگرد</h1>
      <p>حسابت را بساز و دوره‌های ریاضی را انتخاب کن.</p>
      <ol className="registration-steps" aria-label="مراحل ثبت‌نام">
        <li aria-current={step===1?'step':undefined} className={step===1?'current':'complete'}><span>{step===2?<Check size={17}/>:'۱'}</span>حساب کاربری</li>
        <li aria-current={step===2?'step':undefined} className={step===2?'current':''}><span>۲</span>مشخصات شاگرد</li>
      </ol>
      {step===1?<form className="form-stack" onSubmit={next}>
        <label>نام کاربری<input dir="ltr" autoComplete="username" required minLength={3} maxLength={40} pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{2,39}" value={username} onChange={e=>setUsername(e.target.value)} disabled={busy}/><small className="muted">۳ تا ۴۰ کاراکتر؛ حروف انگلیسی و عدد، نقطه، خط تیره یا زیرخط</small></label>
        <label>رمز عبور<input dir="ltr" type="password" autoComplete="new-password" required minLength={10} maxLength={128} value={password} onChange={e=>setPassword(e.target.value)} disabled={busy}/><small className="muted">حداقل ۱۰ کاراکتر</small></label>
        <label>تکرار رمز عبور<input dir="ltr" type="password" autoComplete="new-password" required minLength={10} maxLength={128} value={confirm} onChange={e=>setConfirm(e.target.value)} disabled={busy}/></label>
        {error&&<p className="inline-error" role="alert">{error}</p>}
        <button className="button primary" disabled={busy}>ادامه و تکمیل مشخصات</button>
      </form>:<form className="form-stack" onSubmit={register}>
        <p className="registration-username">نام کاربری: <b dir="ltr">{username}</b></p>
        <div className="registration-names">
          <label>نام<input autoComplete="given-name" required maxLength={60} value={firstName} onChange={e=>setFirstName(e.target.value)} disabled={busy}/></label>
          <label>نام خانوادگی<input autoComplete="family-name" required maxLength={60} value={lastName} onChange={e=>setLastName(e.target.value)} disabled={busy}/></label>
        </div>
        <label>کد ملی<input dir="ltr" inputMode="numeric" autoComplete="off" required minLength={10} maxLength={10} pattern="[0-9۰-۹٠-٩]{10}" value={nationalId} onChange={e=>setNationalId(e.target.value)} disabled={busy}/><small className="muted">۱۰ رقم؛ صفر ابتدای کد را هم بنویس.</small></label>
        <label>شماره موبایل <span className="muted">(اختیاری)</span><input dir="ltr" type="tel" inputMode="tel" autoComplete="tel-national" maxLength={11} value={phone} onChange={e=>setPhone(e.target.value)} disabled={busy}/><small className="muted">۱۱ رقم، با ۰۹ شروع شود.</small></label>
        <p className="muted">کد ملی و شماره موبایل فقط برای مدرس قابل مشاهده است. دسترسی هر دوره پس از تأیید مدرس یا امور مالی فعال می‌شود.</p>
        {error&&<p className="inline-error" role="alert">{error}</p>}
        <div className="registration-actions"><button className="button primary" disabled={busy}>{busy&&<LoaderCircle className="spin" size={18}/>}ثبت‌نام و ورود به پنل</button><button className="button secondary" type="button" disabled={busy} onClick={()=>{setStep(1);setError('');}}>مرحلهٔ قبل</button></div>
      </form>}
      <p className="auth-switch">قبلاً حساب ساخته‌ای؟ <a href="/login" onClick={loginHref}>ورود به حساب</a></p>
    </section>
  </main>;
}
