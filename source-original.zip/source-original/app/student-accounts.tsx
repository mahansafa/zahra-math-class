'use client';
import {useState} from 'react';
import {Plus,KeyRound,LoaderCircle,UserRound,Copy,Check} from 'lucide-react';
import {Dialog,DialogContent,DialogTitle,DialogHeader,DialogDescription} from '@/components/ui/dialog';
import {Checkbox} from '@/components/ui/checkbox';
import {Switch} from '@/components/ui/switch';
import {toast} from 'sonner';
import type {StudentSummary} from '@/lib/student-profile';

type Student=StudentSummary;
type Course={id:string;title:string};
type Enrollment={user_id:string;course_id:string;status:string};
async function post<T extends object=Record<string,unknown>>(body:Record<string,unknown>):Promise<T>{
  const r=await fetch('/api/classroom',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j=await r.json() as T & {error?:string};
  if(!r.ok)throw new Error(j.error||'عملیات انجام نشد.');
  return j;
}
function CourseAccess({courses,value,onChange,disabled,prefix}:{courses:Course[];value:string[];onChange:(ids:string[])=>void;disabled:boolean;prefix:string}){
  return <fieldset className="course-access" disabled={disabled}>
    <legend>دسترسی به دوره‌ها</legend>
    <p className="muted access-hint">فقط دوره‌های تیک‌خورده برای شاگرد باز می‌شوند.</p>
    {courses.length?<div className="access-options">{courses.map(c=>{
      const checked=value.includes(c.id);
      return <label className={`access-option ${checked?'is-checked':''}`} htmlFor={`${prefix}-${c.id}`} key={c.id}>
        <Checkbox id={`${prefix}-${c.id}`} className="access-checkbox" checked={checked} disabled={disabled}
          onCheckedChange={v=>onChange(v===true?[...value,c.id]:value.filter(id=>id!==c.id))}/>
        <span>{c.title}</span>
      </label>;
    })}</div>:<p className="access-empty">هنوز دوره‌ای نساخته‌ای. بعد از ساخت دوره، می‌توانی از «مدیریت حساب» به شاگرد دسترسی بدهی.</p>}
    {courses.length>0&&<p className="muted access-summary" aria-live="polite">{value.length?`${value.length.toLocaleString('fa-IR')} دوره انتخاب شده`:'فعلاً بدون دسترسی به دوره'}</p>}
  </fieldset>;
}
export default function Accounts({students,courses,enrollments,refresh}:{students:Student[];courses:Course[];enrollments:Enrollment[];refresh:()=>Promise<void>}){
  const [open,setOpen]=useState(false),[managed,setManaged]=useState<Student|null>(null),[name,setName]=useState(''),[login,setLogin]=useState(''),[password,setPassword]=useState(''),[courseIds,setCourseIds]=useState<string[]>([]),[busy,setBusy]=useState(false),[error,setError]=useState(''),[created,setCreated]=useState<{username:string;password:string}|null>(null);
  function start(){setName('');setLogin('');setPassword('');setCourseIds([]);setCreated(null);setError('');setOpen(true);}
  function manage(student:Student){
    setManaged(student);setPassword('');setError('');
    setCourseIds(enrollments.filter(e=>e.user_id===student.id&&e.status==='approved').map(e=>e.course_id));
  }
  async function create(e:React.FormEvent){
    e.preventDefault();setBusy(true);setError('');
    try{const j=await post<{username:string}>({action:'createStudent',name,username:login,password,courseIds});setCreated({username:j.username,password});setPassword('');await refresh();toast.success('حساب شاگرد ساخته شد.');}
    catch(e){setError((e as Error).message);}finally{setBusy(false);}
  }
  async function run(body:Record<string,unknown>,message:string){
    setBusy(true);setError('');
    try{await post(body);await refresh();toast.success(message);return true;}
    catch(e){setError((e as Error).message);return false;}finally{setBusy(false);}
  }
  return <section className="accounts-section">
    <div className="section-label"><div><h2>حساب‌های شاگردها</h2><p>ثبت‌نام‌های شاگردها خودکار اینجا نمایش داده می‌شوند. می‌توانی حساب را دستی هم بسازی.</p></div><div className="student-actions"><a className="button secondary" href="/register">صفحهٔ ثبت‌نام شاگرد</a><button className="button primary" onClick={start}><Plus size={18}/>افزودن شاگرد</button></div></div>
    {students.length?<div className="student-list">{students.map(s=><div className="student-row" key={s.id}>
      <span className="avatar"><UserRound size={19}/></span><div className="student-info"><strong>{s.name}</strong><span dir="ltr">{s.username}</span><small>{s.registration_source==='self'?'ثبت‌نام توسط شاگرد':'افزوده‌شده توسط مدرس'} · {s.must_change?'منتظر تغییر رمز اولیه':'رمز شخصی فعال'}</small></div>
      <span className={`status ${s.active?'approved':''}`}>{s.active?'حساب فعال':'حساب بسته'}</span>
      <button className="button secondary" onClick={()=>manage(s)}><KeyRound size={17}/>مدیریت حساب</button>
    </div>)}</div>:<div className="accounts-empty"><UserRound size={27}/><p>هنوز حساب شاگردی ساخته نشده است.</p><button className="button subtle" onClick={start}>ساخت اولین حساب</button></div>}
    <Dialog open={open} onOpenChange={v=>{if(!busy){setOpen(v);if(!v){setCreated(null);setPassword('');}}}}>
      <DialogContent dir="rtl" className="course-dialog account-dialog"><DialogHeader><DialogTitle>{created?'حساب آماده است':'افزودن شاگرد'}</DialogTitle><DialogDescription>{created?'رمز اولیه را فقط به همین شاگرد بده؛ بعد از بستن این پنجره نمایش داده نمی‌شود.':'شاگرد با این نام کاربری و رمز اولیه وارد کلاس می‌شود.'}</DialogDescription></DialogHeader>
        {created?<div className="form-stack">
          <div className="credential-box"><p>نام کاربری: <b dir="ltr">{created.username}</b></p><p>رمز اولیه: <b dir="ltr">{created.password}</b></p><p className="muted">شاگرد در اولین ورود، رمز را تغییر می‌دهد.</p></div>
          <button className="button secondary" onClick={async()=>{try{await navigator.clipboard.writeText(`نام کاربری: ${created.username}\nرمز اولیه: ${created.password}\nورود به کلاس: ${location.origin}/login`);toast.success('اطلاعات ورود کپی شد.');}catch{toast.error('کپی خودکار انجام نشد؛ اطلاعات را دستی کپی کن.');}}}><Copy size={17}/>کپی اطلاعات ورود</button>
          <button className="button primary" onClick={()=>{setOpen(false);setCreated(null);}}>تمام</button>
        </div>:<form className="form-stack" onSubmit={create}>
          <label>نام و نام خانوادگی<input required maxLength={120} value={name} onChange={e=>setName(e.target.value)} disabled={busy}/></label>
          <label>نام کاربری<input dir="ltr" autoComplete="off" required pattern="[a-zA-Z0-9][a-zA-Z0-9._-]{2,39}" value={login} onChange={e=>setLogin(e.target.value)} placeholder="zahra.student01" disabled={busy}/><small className="muted">حداقل ۳ کاراکتر؛ حروف انگلیسی و عدد</small></label>
          <label>رمز اولیه<input dir="ltr" autoComplete="new-password" type="password" required minLength={10} maxLength={128} value={password} onChange={e=>setPassword(e.target.value)} disabled={busy}/><small className="muted">حداقل ۱۰ کاراکتر</small></label>
          <CourseAccess courses={courses} value={courseIds} onChange={setCourseIds} disabled={busy} prefix="new-student-access"/>
          {error&&<p className="inline-error" role="alert">{error}</p>}
          <button className="button primary" disabled={busy}>{busy?<LoaderCircle className="spin" size={18}/>:<Plus size={18}/>}ساخت حساب شاگرد</button>
        </form>}
      </DialogContent>
    </Dialog>
    <Dialog open={!!managed} onOpenChange={v=>{if(!v&&!busy){setManaged(null);setPassword('');}}}>
      <DialogContent dir="rtl" className="course-dialog account-dialog"><DialogHeader><DialogTitle>مدیریت حساب {managed?.name}</DialogTitle><DialogDescription>نام کاربری: {managed?.username}</DialogDescription></DialogHeader>
        {managed&&<div className="form-stack">
          <dl className="student-profile"><div><dt>نام و نام خانوادگی</dt><dd>{managed.name}</dd></div><div><dt>کد ملی</dt><dd dir="ltr">{managed.national_id||'ثبت نشده'}</dd></div><div><dt>شماره موبایل</dt><dd dir="ltr">{managed.phone||'ثبت نشده'}</dd></div><div><dt>روش ثبت‌نام</dt><dd>{managed.registration_source==='self'?'توسط شاگرد':'توسط مدرس'}</dd></div></dl>
          <div className="account-toggle"><label htmlFor="student-active">حساب فعال</label><Switch id="student-active" dir="ltr" checked={!!(students.find(s=>s.id===managed.id)?.active)} disabled={busy} onCheckedChange={async v=>{await run({action:'setStudentActive',userId:managed.id,active:v},v?'حساب فعال شد.':'حساب بسته شد و نشست‌های ورود لغو شدند.');}}/></div>
          <form className="form-stack" onSubmit={async e=>{e.preventDefault();await run({action:'setStudentCourses',userId:managed.id,courseIds},'دسترسی دوره‌ها ذخیره شد.');}}>
            <CourseAccess courses={courses} value={courseIds} onChange={setCourseIds} disabled={busy} prefix="managed-student-access"/>
            {courses.length>0&&<button className="button primary" disabled={busy}>{busy?<LoaderCircle className="spin" size={18}/>:<Check size={18}/>}ذخیرهٔ دسترسی‌ها</button>}
          </form>
          <form className="form-stack reset-form" onSubmit={async e=>{e.preventDefault();if(await run({action:'resetPassword',userId:managed.id,password},'رمز بازنشانی شد؛ رمز اولیهٔ جدید را به شاگرد بده.'))setPassword('');}}>
            <label>رمز اولیهٔ جدید<input type="password" dir="ltr" autoComplete="new-password" required minLength={10} maxLength={128} value={password} onChange={e=>setPassword(e.target.value)} disabled={busy}/><small className="muted">رمز قبلی و نشست‌های ورود لغو می‌شوند. شاگرد باید رمز جدید را تغییر بدهد.</small></label>
            <button className="button secondary" disabled={busy||password.length<10}>بازنشانی رمز</button>
          </form>
          {error&&<p className="inline-error" role="alert">{error}</p>}
        </div>}
      </DialogContent>
    </Dialog>
  </section>;
}
export function ChangePassword({required=false}:{required?:boolean}){const [open,setOpen]=useState(required),[current,setCurrent]=useState(''),[next,setNext]=useState(''),[confirm,setConfirm]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);async function submit(e:React.FormEvent){e.preventDefault();setError('');if(next!==confirm){setError('تکرار رمز جدید یکسان نیست.');return;}setBusy(true);try{const r=await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'changePassword',currentPassword:current,newPassword:next})});const j:any=await r.json();if(!r.ok)throw new Error(j.error);location.reload();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}return <><button className="button subtle" onClick={()=>setOpen(true)}><KeyRound size={17}/>تغییر رمز</button><Dialog open={open} onOpenChange={v=>{if(!required&&!busy)setOpen(v);}}><DialogContent dir="rtl" showCloseButton={!required} className="course-dialog"><DialogHeader><DialogTitle>{required?'رمز اولیه را تغییر بده':'تغییر رمز عبور'}</DialogTitle><DialogDescription>{required?'قبل از تماشای کلاس، یک رمز شخصی برای حسابت تعیین کن.':'رمز جدید حداقل ۱۰ کاراکتر داشته باشد.'}</DialogDescription></DialogHeader><form className="form-stack" onSubmit={submit}><label>رمز فعلی<input type="password" dir="ltr" autoComplete="current-password" required value={current} onChange={e=>setCurrent(e.target.value)}/></label><label>رمز جدید<input type="password" dir="ltr" autoComplete="new-password" required minLength={10} maxLength={128} value={next} onChange={e=>setNext(e.target.value)}/></label><label>تکرار رمز جدید<input type="password" dir="ltr" autoComplete="new-password" required value={confirm} onChange={e=>setConfirm(e.target.value)}/></label>{error&&<p className="inline-error" role="alert">{error}</p>}<button className="button primary" disabled={busy}>{busy&&<LoaderCircle className="spin" size={18}/>}ذخیرهٔ رمز جدید</button></form></DialogContent></Dialog></>;}
