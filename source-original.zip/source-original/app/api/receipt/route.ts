import {currentIdentity} from '@/lib/student-auth';
import {bucket,clean,db,owner} from '@/lib/classroom';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{
 const u=await currentIdentity();if(!u)return new Response('ابتدا وارد حساب شو.',{status:401});
 const id=clean(new URL(req.url).searchParams.get('order'));
 const o=await db().prepare('SELECT user_id,receipt_key,receipt_mime FROM orders WHERE id = ?').bind(id).first<{user_id:string;receipt_key:string|null;receipt_mime:string|null}>();
 const isAdmin=u.kind==='teacher'&&await owner()===u.userId;
 if(!o||(!isAdmin&&o.user_id!==u.userId)||!o.receipt_key)return new Response('رسید پیدا نشد.',{status:404});
 const file=await bucket().get(o.receipt_key);if(!file)return new Response('رسید پیدا نشد.',{status:404});
 return new Response(file.body,{headers:{'Content-Type':o.receipt_mime||'application/octet-stream','Content-Length':String(file.size),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Content-Disposition':'inline','Referrer-Policy':'no-referrer'}});
}catch(e){console.error('receipt read failed',e);return new Response('نمایش رسید موقتاً در دسترس نیست.',{status:503});}}
