import {currentIdentity} from '@/lib/student-auth';
import {sameOrigin} from '@/lib/classroom';
import {mutateShop,shopSnapshot,ShopError,submitReceipt} from '@/lib/shop';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){try{return json(await shopSnapshot(await currentIdentity()));}catch(e){console.error('shop load failed',e);return json({error:'اطلاعات فروشگاه موقتاً در دسترس نیست. دوباره تلاش کن.'},503);}}
export async function POST(req:Request){try{
 sameOrigin(req);
 if(new URL(req.url).searchParams.get('action')==='receipt')return json(await submitReceipt(req));
 if(Number(req.headers.get('content-length'))>65536)return json({error:'درخواست بیش از حد بزرگ است.'},413);
 const body=await req.json();if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'درخواست معتبر نیست.'},400);
 return json(await mutateShop(body as Record<string,unknown>));
}catch(e){console.error('shop save failed',e);return json({error:(e as Error).message||'ذخیره انجام نشد.'},e instanceof ShopError?e.status:400);}}
