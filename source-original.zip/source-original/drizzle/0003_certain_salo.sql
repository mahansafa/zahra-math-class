ALTER TABLE `students` ADD `first_name` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `last_name` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `national_id` text;--> statement-breakpoint
ALTER TABLE `students` ADD `phone` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `registration_source` text DEFAULT 'admin' NOT NULL;