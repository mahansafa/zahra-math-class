CREATE TABLE `cart_items` (
	`user_id` text NOT NULL,
	`course_id` text NOT NULL,
	`created` integer NOT NULL,
	PRIMARY KEY(`user_id`, `course_id`),
	FOREIGN KEY (`user_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`order_id` text NOT NULL,
	`course_id` text NOT NULL,
	`title` text NOT NULL,
	`price` integer NOT NULL,
	PRIMARY KEY(`order_id`, `course_id`),
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`buyer_name` text NOT NULL,
	`buyer_username` text NOT NULL,
	`total` integer NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`payment_card` text NOT NULL,
	`payment_owner` text NOT NULL,
	`receipt_text` text DEFAULT '' NOT NULL,
	`receipt_key` text,
	`receipt_mime` text,
	`receipt_size` integer,
	`review_note` text DEFAULT '' NOT NULL,
	`reviewer` text,
	`review_token` text,
	`created` integer NOT NULL,
	`submitted` integer,
	`reviewed` integer,
	FOREIGN KEY (`user_id`) REFERENCES `students`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_orders_user_created` ON `orders` (`user_id`,`created`);--> statement-breakpoint
CREATE INDEX `idx_orders_status_created` ON `orders` (`status`,`created`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_orders_one_draft` ON `orders` (`user_id`) WHERE "orders"."status" = 'draft';--> statement-breakpoint
ALTER TABLE `courses` ADD `price` integer;