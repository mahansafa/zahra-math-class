'use client';
import {useEffect,useRef,useState} from 'react';
import {BookOpen,ShoppingBag,ShoppingCart,CreditCard,ReceiptText,Plus,Trash2,Check,Copy,LoaderCircle,RefreshCw,LogOut,Upload,ShieldCheck} from 'lucide-react';
import {Toaster} from '@/components/ui/sonner';
import {toast} from 'sonner';
import {ChangePassword} from './student-accounts';
import type {PaymentDetails,ShopCourse,ShopData,ShopOrder,ShopViewer} from '@/lib/shop-types';
const money=(n:number)=>n.toLocaleString('fa-IR')+' تومان';
const fa=(n:number)=>n.toLocaleString('fa-IR');
const toDigits=(s:string)=>s.replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
const statuses={draft:'در انتظار ارسال رسید',pending:'در انتظار بررسی مالی',approved:'تأیید شده',rejected:'تأیید نشد',cancelled:'لغو شده'};
type Mutation=(body:Record<string,unknown>,message:string)=>Promise<boolean>;
async function post<T extends object=Record<string,unknown>>(body:Record<string,unknown>):Promise<T>{
 const r=await fetch('/api/shop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 const j=await r.json() as T&{error?:string};if(!r.ok)throw new Error(j.error||'عملیات انجام نشد.');return j;
}
function CoursePrice({course,busy,run}:{course:ShopCourse;busy:boolean;run:Mutation}){
 const [value,setValue]=useState(course.price===null?'':String(course.price));
 const amount=Number(toDigits(value).replace(/[,٬\s]/g,''));
 return <form className="price-form" onSubmit={e=>{e.preventDefault();void run({action:'setPrice',courseId:course.id,price:amount},'قیمت دوره ذخیره شد.');}}>
  <label htmlFor={`price-${course.id}`}>قیمت دوره <span className="muted">تومان</span></label>
  <div className="price-input-row"><input id={`price-${course.id}`} dir="ltr" inputMode="numeric" value={value} onChange={e=>setValue(e.target.value)} placeholder="مثلاً 1500000" maxLength={16} disabled={busy}/><button className="button primary" disabled={busy||!value.trim()||!Number.isSafeInteger(amount)||amount<1||amount>1_000_000_000}>ذخیره</button></div>
  {course.price!==null&&<button type="button" className="button subtle remove-price" disabled={busy} onClick={()=>run({action:'setPrice',courseId:course.id,price:null},'قیمت حذف شد؛ خرید این دوره تا تعیین قیمت غیرفعال است.')}>حذف قیمت</button>}
 </form>;
}
function PaymentSettings({value,busy,run}:{value:PaymentDetails;busy:boolean;run:Mutation}){
 const [card,setCard]=useState(value.cardNumber),[holder,setHolder]=useState(value.cardOwner);
 return <section className="form-card payment-settings"><div className="form-heading"><span className="section-icon"><CreditCard/></span><div><h2>مشخصات کارت واریز</h2><p>این مشخصات در مرحلهٔ واریز به شاگرد نشان داده می‌شود.</p></div></div>
  <form className="form-stack" onSubmit={e=>{e.preventDefault();void run({action:'setPayment',cardNumber:card,cardOwner:holder},'شماره کارت و نام مالک ذخیره شد.');}}>
   <div className="payment-fields"><label>شماره کارت<input dir="ltr" inputMode="numeric" autoComplete="off" value={card} onChange={e=>setCard(e.target.value)} placeholder="شماره کارت ۱۶ رقمی" maxLength={24} required disabled={busy}/></label><label>نام مالک کارت<input value={holder} onChange={e=>setHolder(e.target.value)} maxLength={120} required disabled={busy}/></label></div>
   <div className="form-actions"><button className="button primary" disabled={busy||!card.trim()||!holder.trim()}><Check size={18}/>ذخیرهٔ مشخصات واریز</button><span className="muted">تغییرات برای سفارش‌های جدید اعمال می‌شود.</span></div>
  </form>
 </section>;
}
function PaymentCard({card,holder}:{card:string;holder:string}){
 return <section className="payment-details"><div className="payment-title"><CreditCard size={22}/><h2>واریز به کارت</h2></div><p className="card-number" dir="ltr">{card.replace(/(.{4})/g,'$1 ').trim()}</p><div className="card-holder"><span>به نام</span><strong>{holder}</strong></div><button type="button" className="button secondary" onClick={async()=>{try{await navigator.clipboard.writeText(card);toast.success('شماره کارت کپی شد.');}catch{toast.error('کپی خودکار انجام نشد؛ شماره کارت را دستی کپی کن.');}}}><Copy size={17}/>کپی شماره کارت</button></section>;
}
function OrderLines({order}:{order:ShopOrder}){
 return <div className="order-lines">{order.items.map(i=><div className="order-line" key={i.course_id}><span>{i.title}</span><strong>{money(i.price)}</strong></div>)}<div className="order-total"><span>مبلغ کل سفارش</span><strong>{money(order.total)}</strong></div></div>;
}
function ReceiptForm({order,busy,onSubmitted,setBusy,setError}:{order:ShopOrder;busy:boolean;onSubmitted:()=>Promise<void>;setBusy:(v:boolean)=>void;setError:(s:string)=>void}){
 const [text,setText]=useState(''),[file,setFile]=useState<File|null>(null),[preview,setPreview]=useState(''),[fileError,setFileError]=useState('');const input=useRef<HTMLInputElement>(null);
 useEffect(()=>{if(!file){setPreview('');return;}const url=URL.createObjectURL(file);setPreview(url);return()=>URL.revokeObjectURL(url);},[file]);
 async function submit(e:React.FormEvent){
  e.preventDefault();if(!text.trim()&&!file)return;setBusy(true);setError('');
  try{const body=new FormData();body.append('text',text);if(file)body.append('image',file);const r=await fetch('/api/shop?action=receipt&order='+encodeURIComponent(order.id),{method:'POST',body});const j=await r.json() as {error?:string};if(!r.ok)throw new Error(j.error||'ارسال رسید انجام نشد.');await onSubmitted();toast.success('سفارش و رسید برای امور مالی ارسال شد.');}
  catch(e){setError((e as Error).message);}finally{setBusy(false);}
 }
 return <form className="form-stack receipt-form" onSubmit={submit}><div><h2>ارسال رسید واریز</h2><p className="muted">بعد از واریز مبلغ بالا، عکس فیش یا اطلاعات پرداخت را وارد کن. می‌توانی هر دو را بفرستی.</p></div>
  <label className={`file-drop receipt-drop ${file?'has-file':''}`}><Upload size={27}/><strong>{file?file.name:'انتخاب عکس فیش واریز'}</strong><span>JPG، PNG یا WebP · حداکثر ۵ مگابایت</span><input ref={input} type="file" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp" disabled={busy} onChange={e=>{const next=e.target.files?.[0]||null;setFileError('');if(next&&next.size>5*1024**2){setFile(null);setFileError('حجم عکس بیشتر از ۵ مگابایت است.');e.target.value='';return;}if(next&&!next.size){setFile(null);setFileError('فایل انتخاب‌شده خالی است.');return;}setFile(next);}}/></label>
  {preview&&<div className="receipt-preview"><img src={preview} alt="پیش‌نمایش فیش انتخاب‌شده"/><button type="button" className="button subtle" disabled={busy} onClick={()=>{setFile(null);if(input.current)input.current.value='';}}>حذف عکس</button></div>}
  {fileError&&<p className="inline-error" role="alert">{fileError}</p>}
  <label>متن اطلاعات واریز<textarea rows={4} maxLength={4000} value={text} onChange={e=>setText(e.target.value)} disabled={busy} placeholder="مثلاً: مبلغ واریز، تاریخ و ساعت و شمارهٔ پیگیری"/></label>
  <p className="receipt-requirement">برای ارسال، حداقل یکی از دو بخش «عکس فیش» یا «متن اطلاعات واریز» باید پر باشد.</p>
  <button className="button primary" disabled={busy||(!text.trim()&&!file)}>{busy?<LoaderCircle size={18} className="spin"/>:<ReceiptText size={18}/>}ارسال برای امور مالی</button>
 </form>;
}
function OrderCard({order,finance,busy,run}:{order:ShopOrder;finance:boolean;busy:boolean;run:Mutation}){
 const [note,setNote]=useState('');
 return <article className="order-card"><div className="order-card-heading"><div><p className="eyebrow">سفارش <bdi>{order.id.slice(0,8).toUpperCase()}</bdi></p><h3>{finance?order.buyer_name:'خرید دوره‌ها'}</h3>{finance&&<p className="muted"><bdi>{order.buyer_username}</bdi></p>}<p className="muted">{new Date(order.submitted||order.created).toLocaleString('fa-IR',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Tehran'})}</p></div><span className={`status order-status ${order.status}`}>{statuses[order.status]}</span></div>
  <OrderLines order={order}/>
  {finance&&<p className="order-bank">واریز به <bdi>{order.payment_card}</bdi> · {order.payment_owner}</p>}
  {order.receipt_text&&<div className="receipt-text"><strong>اطلاعات واریز</strong><p>{order.receipt_text}</p></div>}
  {order.hasReceipt&&<div className="submitted-receipt">{finance&&<a href={'/api/receipt?order='+encodeURIComponent(order.id)} target="_blank" rel="noopener noreferrer"><img loading="lazy" src={'/api/receipt?order='+encodeURIComponent(order.id)} alt={'فیش واریز '+order.buyer_name}/></a>}<a className="button secondary" href={'/api/receipt?order='+encodeURIComponent(order.id)} target="_blank" rel="noopener noreferrer">مشاهدهٔ عکس فیش</a></div>}
  {order.review_note&&<div className="review-note"><strong>توضیح امور مالی</strong><p>{order.review_note}</p></div>}
  {order.status==='approved'&&!finance&&<p className="order-success"><ShieldCheck size={18}/>دوره‌های این سفارش برایت فعال شده‌اند. <a href="/">رفتن به کلاس‌ها</a></p>}
  {order.status==='rejected'&&!finance&&<p className="muted">برای پیگیری این واریز با مدرس تماس بگیر؛ اگر دوباره خرید می‌کنی، می‌توانی دوره‌ها را از فروشگاه انتخاب کنی.</p>}
  {finance&&order.status==='pending'&&<div className="finance-review"><label htmlFor={'review-'+order.id}>توضیح بررسی <span className="muted">اختیاری؛ شاگرد آن را می‌بیند</span><textarea id={'review-'+order.id} rows={2} maxLength={1000} value={note} onChange={e=>setNote(e.target.value)} disabled={busy}/></label><div className="form-actions"><button className="button primary" disabled={busy} onClick={()=>run({action:'reviewOrder',orderId:order.id,decision:'approved',note},'سفارش تأیید شد و دوره‌های آن برای شاگرد فعال شدند.')}><Check size={18}/>تأیید و فعال‌سازی دوره‌ها</button><button className="button secondary" disabled={busy} onClick={()=>run({action:'reviewOrder',orderId:order.id,decision:'rejected',note},'سفارش تأیید نشد؛ دسترسی جدیدی فعال نشد.')}>تأیید نمی‌شود</button></div></div>}
 </article>;
}
export default function ShopClient({mode,initial,viewer,initialError}:{mode:'store'|'cart'|'finance';initial:ShopData;viewer:ShopViewer;initialError:string}){
 const [data,setData]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState(initialError),[filter,setFilter]=useState<'pending'|'all'>('pending');
 const isStudent=viewer?.kind==='student',draft=data.orders.find(o=>o.status==='draft'&&o.user_id===viewer?.id),cart=data.cart.map(id=>data.courses.find(c=>c.id===id)).filter((c):c is ShopCourse=>!!c),total=cart.reduce((sum,c)=>sum+(c.price||0),0);
 const history=data.orders.filter(o=>o.status!=='draft'&&o.status!=='cancelled');
 async function refresh(){const r=await fetch('/api/shop');const j=await r.json() as ShopData&{error?:string};if(!r.ok)throw new Error(j.error||'به‌روزرسانی انجام نشد.');setData(j);setError('');}
 async function run(body:Record<string,unknown>,message:string){setBusy(true);setError('');try{await post(body);await refresh();toast.success(message);return true;}catch(e){setError((e as Error).message);return false;}finally{setBusy(false);}}
 async function checkout(){setBusy(true);setError('');try{await post({action:'startCheckout',items:cart.map(c=>({id:c.id,price:c.price}))});await refresh();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 const titles={store:'فروشگاه دوره‌های ریاضی',cart:'سبد خرید و واریز',finance:'امور مالی'};
 return <><Toaster dir="rtl" position="top-center"/><header className="topbar"><a className="brand" href="/"><span className="brand-mark">∑</span><div><strong>مهندس زهرا تعویذی</strong><span>کلاس‌های ریاضی</span></div></a><div className="top-actions">{viewer?<><span className="username">{data.isAdmin?'پنل مدرس':viewer.name}</span>{isStudent&&<ChangePassword required={viewer.mustChange}/>}<a className="icon-button" aria-label="خروج از حساب" href={isStudent?'/login':'/admin-login?logout=1'} target="_top" onClick={async e=>{if(isStudent){e.preventDefault();await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})});location.href='/login';}}}><LogOut size={19}/></a></>:<><a className="button primary" href={'/login?next='+encodeURIComponent(mode==='cart'?'/cart':'/store')}>ورود شاگرد</a><a className="button secondary" href={'/register?next='+encodeURIComponent(mode==='cart'?'/cart':'/store')}>ثبت‌نام</a></>}</div></header>
  <main className="main shop-main"><nav className="shop-nav" aria-label="بخش‌های سایت"><a href="/"><BookOpen size={18}/>{data.isAdmin?'پنل مدرس':'کلاس‌ها'}</a><a href="/store" aria-current={mode==='store'?'page':undefined}><ShoppingBag size={18}/>فروشگاه</a>{!data.isAdmin&&<a href="/cart" aria-current={mode==='cart'?'page':undefined}><ShoppingCart size={18}/>سبد خرید{data.cart.length>0&&<span className="count">{fa(data.cart.length)}</span>}</a>}{data.isAdmin&&<a href="/finance" aria-current={mode==='finance'?'page':undefined}><ReceiptText size={18}/>امور مالی{data.orders.filter(o=>o.status==='pending').length>0&&<span className="count">{fa(data.orders.filter(o=>o.status==='pending').length)}</span>}</a>}</nav>
   <div className="page-heading"><div><h1>{titles[mode]}</h1><p className="intro">{mode==='store'?(data.isAdmin?'قیمت دوره‌ها و مشخصات واریز را اینجا تعیین کن.':'دوره‌ها را انتخاب کن و در سبد خرید، رسید واریز را بفرست.'):mode==='cart'?'دسترسی دوره‌ها پس از بررسی و تأیید امور مالی فعال می‌شود.':'سفارش‌ها، مبلغ و فیش واریز را بررسی کن.'}</p></div><button className="button secondary" disabled={busy} onClick={()=>refresh().catch(e=>setError((e as Error).message))}><RefreshCw size={17}/>به‌روزرسانی</button></div>
   {error&&<div className="error-banner" role="alert">{error}</div>}
   {mode==='store'&&<>
    {data.isAdmin&&<PaymentSettings key={data.payment.cardNumber+data.payment.cardOwner} value={data.payment} busy={busy} run={run}/>}
    {draft&&!data.isAdmin&&<div className="access-banner"><ReceiptText size={22}/><div><strong>یک سفارش آمادهٔ واریز داری.</strong><p>برای ادامهٔ واریز یا تغییر دوره‌ها، به سبد خرید برو.</p></div><a className="button primary" href="/cart">ادامهٔ سفارش</a></div>}
    {!data.courses.length?<section className="shop-empty"><ShoppingBag size={34}/><h2>هنوز دوره‌ای ساخته نشده است.</h2><p>{data.isAdmin?'از پنل مدرس یک دوره بساز؛ همان دوره در فروشگاه هم ظاهر می‌شود.':'دوره‌ها پس از انتشار مدرس اینجا نمایش داده می‌شوند.'}</p>{data.isAdmin&&<a className="button primary" href="/">رفتن به پنل مدرس</a>}</section>:<div className="store-grid">{data.courses.map((c,i)=>{
     const owned=data.owned.includes(c.id),pending=data.pending.includes(c.id),inCart=data.cart.includes(c.id);
     return <article className="store-course" key={c.id}><div className="store-course-heading"><span className="store-course-symbol"><BookOpen size={26}/></span><span className="muted">دورهٔ {fa(i+1)} · {fa(c.lesson_count)} جلسه</span></div><h2>{c.title}</h2>{c.description&&<p className="store-description">{c.description}</p>}<p className={`store-price ${c.price===null?'unpriced':''}`}>{c.price===null?'قیمت هنوز تعیین نشده':money(c.price)}</p>
      {data.isAdmin?<CoursePrice key={c.id+'-'+c.price} course={c} busy={busy} run={run}/>:owned?<a className="button secondary" href="/"><Check size={18}/>دوره برایت فعال است</a>:pending?<span className="store-pending">در انتظار بررسی مالی</span>:!viewer?<a className="button primary" href="/login?next=%2Fstore">ورود برای خرید</a>:inCart?<a className="button secondary" href="/cart"><ShoppingCart size={18}/>در سبد خرید</a>:<button className="button primary" disabled={busy||c.price===null||!!draft||viewer.mustChange} onClick={()=>run({action:'addCart',courseId:c.id},'دوره به سبد خرید اضافه شد.')}><Plus size={18}/>افزودن به سبد خرید</button>}
     </article>;
    })}</div>}
    {!data.isAdmin&&cart.length>0&&<div className="store-cart-bar"><span>{fa(cart.length)} دوره در سبد خرید</span><strong>{money(total)}</strong><a className="button primary" href="/cart"><ShoppingCart size={18}/>مشاهدهٔ سبد خرید</a></div>}
   </>}
   {mode==='cart'&&(!isStudent?<section className="shop-empty"><ShoppingCart size={34}/><h2>خرید دوره از پنل شاگرد انجام می‌شود.</h2><p>وارد حسابت شو یا یک حساب شاگرد بساز.</p>{!viewer&&<a className="button primary" href="/login?next=%2Fcart">ورود به حساب شاگرد</a>}</section>:<>
    {draft?<div className="checkout-grid"><section className="form-card"><div className="form-heading"><span className="section-icon"><ReceiptText/></span><div><h2>سفارش آمادهٔ واریز</h2><p>مبلغ و دوره‌های این سفارش ثبت شده‌اند.</p></div></div><OrderLines order={draft}/><button className="button subtle" disabled={busy} onClick={()=>run({action:'cancelCheckout',orderId:draft.id},'حالا می‌توانی سبد خرید را ویرایش کنی.')}>ویرایش سبد پیش از واریز</button><p className="muted">اگر واریز کرده‌ای، همین سفارش را با رسید آن ارسال کن.</p><ReceiptForm order={draft} busy={busy} setBusy={setBusy} setError={setError} onSubmitted={refresh}/></section><aside><PaymentCard card={draft.payment_card} holder={draft.payment_owner}/><div className="setup-note"><ShieldCheck size={20}/><strong>پس از ارسال رسید</strong><p>سفارش به امور مالی می‌رود. نتیجهٔ بررسی را در پایین همین صفحه می‌بینی.</p></div></aside></div>:cart.length?<div className="checkout-grid"><section className="form-card"><h2>دوره‌های انتخاب‌شده</h2><div className="cart-list">{cart.map(c=><div className="cart-row" key={c.id}><span className="avatar"><BookOpen size={21}/></span><div><strong>{c.title}</strong><p className="muted">{fa(c.lesson_count)} جلسه{data.owned.includes(c.id)?' · از قبل فعال':data.pending.includes(c.id)?' · در انتظار بررسی مالی':''}</p></div><strong>{c.price===null?'قیمت تعیین نشده':money(c.price)}</strong><button className="icon-button" aria-label={'حذف '+c.title+' از سبد'} disabled={busy} onClick={()=>run({action:'removeCart',courseId:c.id},'دوره از سبد حذف شد.')}><Trash2 size={18}/></button></div>)}</div><div className="order-total"><span>جمع مبلغ دوره‌ها</span><strong>{money(total)}</strong></div><button className="button primary checkout-button" disabled={busy||viewer.mustChange||cart.some(c=>c.price===null||data.owned.includes(c.id)||data.pending.includes(c.id))||!data.payment.cardNumber||!data.payment.cardOwner} onClick={checkout}>{busy?<LoaderCircle size={18} className="spin"/>:<CreditCard size={18}/>}ادامهٔ خرید و دریافت اطلاعات واریز</button><p className="muted">در مرحلهٔ بعد شماره کارت، نام مالک و بخش ارسال رسید را می‌بینی.</p></section><aside className="cart-summary"><h2>خلاصهٔ خرید</h2><p>{fa(cart.length)} دوره</p><strong>{money(total)}</strong><p className="muted">فقط پس از تأیید امور مالی، دوره‌های خریداری‌شده فعال می‌شوند.</p>{(!data.payment.cardNumber||!data.payment.cardOwner)&&<p className="inline-error">مدرس هنوز مشخصات واریز را ثبت نکرده است.</p>}</aside></div>:<section className="shop-empty"><ShoppingCart size={34}/><h2>سبد خریدت خالی است.</h2><p>دوره‌های موردنظرت را از فروشگاه انتخاب کن.</p><a className="button primary" href="/store">رفتن به فروشگاه</a></section>}
    {history.length>0&&<section className="order-history"><div className="section-label"><div><h2>خریدها و نتیجهٔ بررسی مالی</h2><p>برای دیدن آخرین وضعیت، «به‌روزرسانی» را بزن.</p></div></div><div className="orders-list">{history.map(o=><OrderCard key={o.id} order={o} finance={false} busy={busy} run={run}/>)}</div></section>}
   </>)}
   {mode==='finance'&&(data.isAdmin?<>
    <PaymentSettings key={data.payment.cardNumber+data.payment.cardOwner} value={data.payment} busy={busy} run={run}/>
    <div className="finance-filter" role="group" aria-label="نمایش سفارش‌ها"><button className={`button ${filter==='pending'?'primary':'secondary'}`} aria-pressed={filter==='pending'} onClick={()=>setFilter('pending')}>در انتظار بررسی · {fa(history.filter(o=>o.status==='pending').length)}</button><button className={`button ${filter==='all'?'primary':'secondary'}`} aria-pressed={filter==='all'} onClick={()=>setFilter('all')}>همهٔ سفارش‌ها</button></div>
    {history.filter(o=>filter==='all'||o.status==='pending').length?<div className="orders-list finance-orders">{history.filter(o=>filter==='all'||o.status==='pending').map(o=><OrderCard key={o.id} order={o} finance busy={busy} run={run}/>)}</div>:<section className="shop-empty"><ReceiptText size={34}/><h2>{filter==='pending'?'سفارشی در انتظار بررسی نیست.':'هنوز سفارشی ارسال نشده است.'}</h2><p>سفارش شاگرد، دوره‌های انتخاب‌شده و رسید واریز پس از ارسال اینجا نمایش داده می‌شوند.</p></section>}
   </>:<section className="shop-empty"><ShieldCheck size={34}/><h2>این بخش مخصوص مدیر سایت است.</h2>{!viewer&&<a className="button primary" href="/admin-login?next=%2Ffinance" target="_top">ورود مدیر</a>}</section>)}
   <footer className="footer"><span>© کلاس ریاضی · مهندس زهرا تعویذی</span><span>پرداخت با واریز به کارت و تأیید امور مالی</span></footer>
  </main>
 </>;
}
