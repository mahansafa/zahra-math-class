'use client';
import { useState, useEffect } from 'react';
import { LockKeyhole, LoaderCircle } from 'lucide-react';
export default function AdminLogin() {
  const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[leaving,setLeaving]=useState(false);
  useEffect(()=>{ if(new URLSearchParams(location.search).get('logout')==='1') {
    setLeaving(true);
    fetch('/api/admin-auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})})
      .then(r=>{if(!r.ok)throw new Error('خروج انجام نشد. دوباره تلاش کنید.');location.replace('/admin-login');})
      .catch(e=>{setError(e.message);setLeaving(false);});
  } },[]);
  async function submit(e:React.FormEvent) {
    e.preventDefault();setBusy(true);setError('');
    try {
      const r=await fetch('/api/admin-auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'login',username,password})});
      const j=await r.json() as {error?:string};if(!r.ok)throw new Error(j.error||'ورود انجام نشد.');
      // Clear any student session so the independent administrator session wins.
      await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'logout'})});
      const next=new URLSearchParams(location.search).get('next');location.href=next==='/finance'?next:'/';
    } catch(e) {setError((e as Error).message);} finally {setBusy(false);}
  }
  return <main className="login-shell"><a href="/" className="brand"><span className="brand-mark">∑</span><div><strong>مهندس زهرا تعویذی</strong><span>کلاس‌های ریاضی</span></div></a><section className="login-card"><span className="section-icon"><LockKeyhole/></span><h1>ورود مدیر سایت</h1><form className="form-stack" onSubmit={submit}><label>نام کاربری<input dir="ltr" autoComplete="username" required maxLength={40} value={username} onChange={e=>setUsername(e.target.value)}/></label><label>رمز عبور<input dir="ltr" type="password" autoComplete="current-password" required maxLength={128} value={password} onChange={e=>setPassword(e.target.value)}/></label>{error&&<p role="alert" className="inline-error">{error}</p>}<button className="button primary" disabled={busy||leaving}>{(busy||leaving)&&<LoaderCircle className="spin" size={18}/>}ورود به مدیریت</button></form><a className="teacher-login" href="/login">ورود شاگرد</a></section></main>;
}
