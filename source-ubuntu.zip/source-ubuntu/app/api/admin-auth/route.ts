import { sameOrigin } from '@/lib/classroom';
import { authBody } from '@/lib/self-registration';
import { loginAdmin, logoutAdmin, adminCookie } from '@/lib/iran-admin';
export const dynamic='force-dynamic';
export async function POST(req:Request) {
  try {
    sameOrigin(req); const input=await authBody(req) as Record<string,unknown>;
    if(input.action==='logout') { await logoutAdmin(); return Response.json({ok:true},{headers:{'Set-Cookie':adminCookie('',true),'Cache-Control':'no-store'}}); }
    if(input.action!=='login') return Response.json({error:'درخواست معتبر نیست.'},{status:400});
    const token=await loginAdmin(input,req.headers.get('cf-connecting-ip')||'unknown');
    if(!token) return Response.json({error:'نام کاربری یا رمز عبور صحیح نیست.'},{status:401,headers:{'Cache-Control':'no-store'}});
    return Response.json({ok:true},{headers:{'Set-Cookie':adminCookie(token),'Cache-Control':'no-store'}});
  } catch(e) { return Response.json({error:(e as Error).message},{status:400,headers:{'Cache-Control':'no-store'}}); }
}
