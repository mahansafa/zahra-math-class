import { getAdminIdentity } from '@/lib/iran-admin';
import { redirect } from 'next/navigation';
export type ChatGPTUser={userId:string;displayName:string;email:string;fullName:string|null};
export const getChatGPTUser=getAdminIdentity;
export function chatGPTSignInPath(returnTo:string){return '/admin-login'+(returnTo==='/finance'?'?next=%2Ffinance':'');}
export function chatGPTSignOutPath(){return '/admin-login?logout=1';}
export async function requireChatGPTUser(returnTo:string){const user=await getAdminIdentity();if(user)return user;redirect(chatGPTSignInPath(returnTo));}
