import { cookies } from 'next/headers';
import { timingSafeEqual } from 'node:crypto';
import { db } from '@/lib/classroom';
import { digest, username, hashPassword } from '@/lib/student-auth';
const COOKIE = '__Host-math-admin';
const HOURS = 2;
export async function getAdminIdentity() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const row = await db().prepare('SELECT a.id,a.name,a.email FROM iran_admin_sessions s JOIN iran_admins a ON a.id=s.admin_id WHERE s.token_hash=? AND s.expires>? AND a.active=1').bind(await digest(token), Date.now()).first<{ id:string; name:string; email:string }>();
  return row ? { userId:row.id, displayName:row.name, fullName:row.name, email:row.email } : null;
}
export function adminCookie(token:string, clear=false) {
  return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${clear?0:HOURS*3600}`;
}
export async function logoutAdmin() {
  const token=(await cookies()).get(COOKIE)?.value;
  if(token) await db().prepare('DELETE FROM iran_admin_sessions WHERE token_hash=?').bind(await digest(token)).run();
}
export async function loginAdmin(input:Record<string,unknown>, ip:string) {
  const name=username(input.username);
  const now=Date.now();
  for(const key of ['admin:ip:'+ip,'admin:user:'+name]) {
    await db().prepare('INSERT INTO login_limits (key,attempts,reset) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN reset < ? THEN 1 ELSE attempts+1 END, reset=CASE WHEN reset < ? THEN ? ELSE reset END').bind(key,1,now+15*60000,now,now,now+15*60000).run();
    const limit=await db().prepare('SELECT attempts FROM login_limits WHERE key=?').bind(key).first<{attempts:number}>();
    if(limit!.attempts>10) throw new Error('تعداد تلاش‌ها زیاد شده است. ۱۵ دقیقه بعد دوباره امتحان کنید.');
  }
  const row=await db().prepare('SELECT * FROM iran_admins WHERE username=?').bind(name).first<{id:string;password_hash:string;salt:string;active:number}>();
  const candidate=await hashPassword(typeof input.password==='string'?input.password.slice(0,128):'',row?.salt||'missing-admin');
  const expected=row?.password_hash||'0'.repeat(64);
  if(!row||!row.active||!timingSafeEqual(Buffer.from(candidate,'hex'),Buffer.from(expected,'hex'))) return null;
  const token=Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('hex');
  await db().prepare('INSERT INTO iran_admin_sessions (token_hash,admin_id,expires) VALUES (?,?,?)').bind(await digest(token),row.id,now+HOURS*3600000).run();
  return token;
}
